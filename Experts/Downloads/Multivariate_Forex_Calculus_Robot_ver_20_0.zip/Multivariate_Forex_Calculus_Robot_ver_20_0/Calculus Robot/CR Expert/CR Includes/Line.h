/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_LINE
#define FILE_LINE

#include "PastPoint.h"
#include "Values.h"
#include "PointDate.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/DateTime.h"

//+------------------------------------------------------------------+
class CLine{
    private:
        IGenericObjectArray<CPointDate> m_Points;
        
    public:
        void Init(CValues &values, CPastPoint &point)
        {
            m_Points.Resize(point.PointsAmount());
            for(int i=0;i<point.PointsAmount();i++)
            {
                if(point.Symbol)
                {
                    if(point.SymbolBuy)
                    {
                        (*(m_Points.GetPointerToValue(i))).Value = values.ReturnPastValueNrToBuy(point.ReturnPointNr(i), point.SymbolNr);
                    }
                    else
                    {
                        (*(m_Points.GetPointerToValue(i))).Value = values.ReturnPastValueNrToSell(point.ReturnPointNr(i), point.SymbolNr);
                    }
                }
                else
                {
                    if(point.SymbolBuy)
                    {
                        (*(m_Points.GetPointerToValue(i))).Value = values.ReturnOtherPastValueNrToBuy(point.ReturnPointNr(i), point.SymbolNr);
                    }
                    else
                    {
                        (*(m_Points.GetPointerToValue(i))).Value = values.ReturnOtherPastValueNrToSell(point.ReturnPointNr(i), point.SymbolNr);
                    }
                }
                (*(m_Points.GetPointerToValue(i))).Time = values.ReturnDateTimeOfPastNr(point.ReturnPointNr(i));
            }
        }
      
        void Init(IString &symbol, IDateTime &MM, IDateTime &EMM)
        {
            int span = (int)IDateTime::SecondsDiff(MM, EMM);
            IDateTime beg = IDateTime::AddSeconds(MM, -(int)(CConfig::PastPointsFraction * span));
            int pointsAmount = IDateTime::MinutesDiff(beg, EMM) + 1;
            IDateTime date;
            
            m_Points.Resize(pointsAmount);
            for(int i=0;i<pointsAmount;i++)
            {
                date = IDateTime::AddMinutes(beg, i);
                (*(m_Points.GetPointerToValue(i))).Value = CValues::GetPriceAtTime(symbol, date);
                (*(m_Points.GetPointerToValue(i))).Time = date;
            }
        }
        
        int PointsAmount()
        {
            return m_Points.Size();
        }
        
        IDateTime MinTime()
        {
            IDateTime time = (*(m_Points.GetPointerToValue(0))).Time;
            
            for(int i=1;i<m_Points.Size();i++)
            {
                if((*(m_Points.GetPointerToValue(i))).Time < time)
                {
                    time = (*(m_Points.GetPointerToValue(i))).Time;
                } 
            }
            return time;
        }
        
        IDateTime MaxTime()
        {
            IDateTime time = (*(m_Points.GetPointerToValue(0))).Time;
            
            for(int i=1;i<m_Points.Size();i++)
            {
                if((*(m_Points.GetPointerToValue(i))).Time > time)
                {
                    time = (*(m_Points.GetPointerToValue(i))).Time;
                }
            }
            return time;
        }
        
        double ApproximatedValue(double position, IDateTime &minTime, IDateTime &maxTime)
        {
            double val = 0.0;
            double secondsSpan = IDateTime::SecondsDiff(minTime, maxTime);
            IDateTime positionTime = IDateTime::AddSeconds(minTime, (int)(secondsSpan * position));        
        
            if(secondsSpan == 0.0)
            {
                secondsSpan = 1.0;
            }
        
            for(int i=0;i<m_Points.Size();i++)
            {
                if((*(m_Points.GetPointerToValue(i))).Time < positionTime)
                {
                    val += (1.0 - IDateTime::SecondsDiff((*(m_Points.GetPointerToValue(i))).Time, positionTime) / secondsSpan) * (*(m_Points.GetPointerToValue(i))).Value;
                }
                else
                {
                    val += (1.0 - IDateTime::SecondsDiff(positionTime, (*(m_Points.GetPointerToValue(i))).Time) / secondsSpan) * (*(m_Points.GetPointerToValue(i))).Value;
                }                
            }
            return val;
        }
};
//+------------------------------------------------------------------+
#endif