/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_VALUE_ANALYZER
#define FILE_VALUE_ANALYZER

#include "Analyzer.h"
#include "Values.h"
#include "PastPoint.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/Interoperability.h"

//+------------------------------------------------------------------+
class CValueAnalyzer {
private:
	long static ProfitSearchNr;

	double m_LastEstablishingMinimumMaximum;
	bool m_SearchingForProfit;
	double m_UpperLimit;
	double m_LowerLimit;

	bool m_Buy;

	double m_Gain;
	double m_Loss;

	int m_GainCount;
	int m_LossCount;

	bool m_DirectionAchivedGuard;
	int m_DirectionAchivedAmount;

	double m_ValueFirstToReach;
	bool m_ValueFirstReached;
	
	double m_ValueSecondToReach;
	bool m_ValueSecondReached;
	
	double m_ValueThirdToReach;
	bool m_ValueThirdReached;
	
	double m_ValueFourthToReach;
	bool m_ValueFourthReached;

	long m_ProfitSearchNr;

	void Reset()
	{
		m_Gain = 0;
		m_Loss = 0;
		m_GainCount = 0;
		m_LossCount = 0;
		m_DirectionAchivedAmount = 0;
	}

	CPastPoint m_Point;

	double ValueToReach(bool buy, double percent, double lastEstablishingMinimumMaximum, double upperLimit, double lowerLimit)
	{
		if (buy)
		{
			return lastEstablishingMinimumMaximum + (upperLimit - lastEstablishingMinimumMaximum) * percent;
		}
		else
		{
			return lastEstablishingMinimumMaximum - (lastEstablishingMinimumMaximum - lowerLimit) * percent;
		}
	}

	void ValueReached(bool buy, double val, double valueToReach, bool &valueReached, IString &msg)
	{
		if (buy)
		{
			if (!valueReached)
			{
				if (val >= valueToReach)
				{
					CLogger::LogSpecial(msg);
					valueReached = true;
				}
			}
		}
		else
		{
			if (!valueReached)
			{
				if (val <= valueToReach)
				{
					CLogger::LogSpecial(msg);
					valueReached = true;
				}
			}
		}
	}

public:
	CValueAnalyzer()
	{
		Reset();
	}

	bool CheckProfit(IString &pair, double val, double &diff, bool log)
	{
		if (m_SearchingForProfit)
		{
			IString msgFirst("First Percent Value Min Reached."); msgFirst += IString(" Profit Search Nr : "); msgFirst += IInteroperability::IntegerToString(m_ProfitSearchNr);
		   IString msgSecond("Second Percent Value Min Reached."); msgSecond += IString(" Profit Search Nr : "); msgSecond += IInteroperability::IntegerToString(m_ProfitSearchNr);
		   IString msgThird("Third Percent Value Min Reached."); msgThird += IString(" Profit Search Nr : "); msgThird += IInteroperability::IntegerToString(m_ProfitSearchNr);
		   IString msgFourth("Fourth Percent Value Min Reached."); msgFourth += IString(" Profit Search Nr : "); msgFourth += IInteroperability::IntegerToString(m_ProfitSearchNr);
		   
			ValueReached(m_Buy, val, m_ValueFirstToReach, m_ValueFirstReached, msgFirst);
			ValueReached(m_Buy, val, m_ValueSecondToReach, m_ValueSecondReached, msgSecond);
			ValueReached(m_Buy, val, m_ValueThirdToReach, m_ValueThirdReached, msgThird);
			ValueReached(m_Buy, val, m_ValueFourthToReach, m_ValueFourthReached, msgFourth);

			if (m_Buy)
			{
				if (!m_DirectionAchivedGuard)
				{
					if (val > m_LastEstablishingMinimumMaximum)
					{
						m_DirectionAchivedGuard = true;
						m_DirectionAchivedAmount++;
					}
				}

				diff = val - m_LastEstablishingMinimumMaximum;

				if (val >= m_UpperLimit)
				{
					m_Gain += (diff);
					m_GainCount++;
					m_SearchingForProfit = false;
					m_Point.Successful = true;
					if (log)
					{
						CLogger::LogSpecial(IString("Profit found, Symbol : ") + pair + ", Operation : " + (m_Buy ? "Buy" : "Sell") + ", SL : " + IInteroperability::DoubleToString(m_UpperLimit) + ", TP : " + IInteroperability::DoubleToString(m_LowerLimit) + ", Profit Search End Nr : " + IInteroperability::IntegerToString(m_ProfitSearchNr));
					}
					return true;
				}
				else if (val < m_LowerLimit)
				{
					m_Loss += (IInteroperability::MathAbs(diff));
					m_LossCount++;
					m_SearchingForProfit = false;
					m_Point.Successful = false;
					if (log)
					{
						CLogger::LogSpecial(IString("Profit lost, Symbol : ") + pair + ", Operation : " + (m_Buy ? "Buy" : "Sell") + ", SL : " + IInteroperability::DoubleToString(m_UpperLimit) + ", TP : " + IInteroperability::DoubleToString(m_LowerLimit) + ", Profit Search End Nr : " + IInteroperability::IntegerToString(m_ProfitSearchNr));
					}
					return true;
				}
			}
			else
			{
				if (!m_DirectionAchivedGuard)
				{
					if (val < m_LastEstablishingMinimumMaximum)
					{
						m_DirectionAchivedGuard = true;
						m_DirectionAchivedAmount++;
					}
				}

				diff = m_LastEstablishingMinimumMaximum - val;

				if (val < m_LowerLimit)
				{
					m_Gain += (diff);
					m_GainCount++;
					m_SearchingForProfit = false;
					m_Point.Successful = true;
					if (log)
					{
						CLogger::LogSpecial(IString("Profit found, Symbol : ") + pair + ", Operation : " + (m_Buy ? "Buy" : "Sell") + ", SL : " + IInteroperability::DoubleToString(m_LowerLimit) + ", TP : " + IInteroperability::DoubleToString(m_UpperLimit) + ", Profit Search End Nr : " + IInteroperability::IntegerToString(m_ProfitSearchNr));
					}
					return true;
				}
				else if (val >= m_UpperLimit)
				{
					m_Loss += (IInteroperability::MathAbs(diff));
					m_LossCount++;
					m_SearchingForProfit = false;
					m_Point.Successful = false;
					if (log)
					{
						CLogger::LogSpecial(IString("Profit lost, Symbol : ") + pair + ", Operation : " + (m_Buy ? "Buy" : "Sell") + ", SL : " + IInteroperability::DoubleToString(m_LowerLimit) + ", TP : " + IInteroperability::DoubleToString(m_UpperLimit) + ", Profit Search End Nr : " + IInteroperability::IntegerToString(m_ProfitSearchNr));
					}
					return true;
				}
			}
		}
		return false;
	}

	void Log(IString &symbol)
	{
		CLogger::Log(symbol + " Gain : " + IInteroperability::DoubleToString(m_Gain) + " Loss : " + IInteroperability::DoubleToString(m_Loss) + " Profit : " + IInteroperability::DoubleToString(Profit()) + " Gain Count : " + IInteroperability::IntegerToString(m_GainCount) + " Loss Count : " + IInteroperability::IntegerToString(m_LossCount));
	}

	int GainCount()
	{
		return m_GainCount;
	}

	int LossCount()
	{
		return m_LossCount;
	}

	double Profit()
	{
		return m_Gain - m_Loss;
	}

	double ProfitMinusSpread(IString &symbol)
	{
		double spread = CValues::Spread(symbol);
		double spreads = spread * (m_GainCount + m_LossCount);

		return Profit() - spreads;
	}

	double ProfitGains()
	{
		double count;

		if (m_LossCount > 0)
		{
			count = m_GainCount / (double)m_LossCount;
		}
		else
		{
			count = m_GainCount;
		}
		return count * Profit();
	}

	bool IsSearchingForProfit()
	{
		return m_SearchingForProfit;
	}

	CPastPoint ReturnPoint()
	{
		return m_Point;
	}

	void SearchForProfit(double lastEstablishingMinimumMaximum, double upperLimit, double lowerLimit, bool buy, CPastPoint &point, bool initial, bool reverseSymbol, bool reverseGlobal)
	{
		m_UpperLimit = upperLimit;
		m_LowerLimit = lowerLimit;
		m_SearchingForProfit = true;
		m_LastEstablishingMinimumMaximum = lastEstablishingMinimumMaximum;
		m_Buy = buy;
		m_Point = point;
		m_DirectionAchivedGuard = false;
		m_ProfitSearchNr = ProfitSearchNr;
		ProfitSearchNr++;

		if (reverseSymbol)
		{
			buy = !buy;
		}

		if (reverseGlobal)
		{
			buy = !buy;
		}

		if (CConfig::ReverseTrades)
		{
			buy = !buy;
		}

		if (initial)
		{
			m_ValueFirstReached = true;
			m_ValueSecondReached = true;
			m_ValueThirdReached = true;
			m_ValueFourthReached = true;
		}
		else
		{
			CLogger::LogSpecial(IString("Profit Search Start Nr : ") + IInteroperability::IntegerToString(m_ProfitSearchNr));

			m_ValueFirstReached = false;
			m_ValueSecondReached = false;
			m_ValueThirdReached = false;
			m_ValueFourthReached = false;
		}

		m_ValueFirstToReach = ValueToReach(buy, CConfig::MinFirstPercentOfProfitReached, lastEstablishingMinimumMaximum, upperLimit, lowerLimit);
		m_ValueSecondToReach = ValueToReach(buy, CConfig::MinSecondPercentOfProfitReached, lastEstablishingMinimumMaximum, upperLimit, lowerLimit);
		m_ValueThirdToReach = ValueToReach(buy, CConfig::MinThirdPercentOfProfitReached, lastEstablishingMinimumMaximum, upperLimit, lowerLimit);
		m_ValueFourthToReach = ValueToReach(buy, CConfig::MinFourthPercentOfProfitReached, lastEstablishingMinimumMaximum, upperLimit, lowerLimit);
	}

	double DirectionAchivedPercent()
	{
		return ((double)(m_DirectionAchivedAmount)) / ((double)(m_GainCount + m_LossCount));
	}
};
long CValueAnalyzer::ProfitSearchNr = 1;
//+------------------------------------------------------------------+
#endif