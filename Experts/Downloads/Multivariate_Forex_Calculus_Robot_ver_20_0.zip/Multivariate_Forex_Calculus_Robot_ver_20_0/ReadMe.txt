Robot will trade on Currency Pairs that are present in "Market Watch Window".
For Testing purposes put there as many Currency Pairs as possible.

By default Robot will run only if Account Leverage is equal or less than 30.

To Run Robot :

- Copy directory "Calculus Robot" to Metatrader 4, ..\MQL4\Experts\ directory. 
- Open file ..\MQL4\Experts\Calculus Robot\MQL4\CalculusRobot.mq4 in MetaEditor and compile it.
- In Metatrader 4 under "Expert Advisors\Calculus Robot\MQL4" run CalculusRobot.

If running on Metatrader 5, change line
#define MQL4 
in file "Calculus Robot\Interoperability\Interoperability.mqh" to line
#define MQL5 

The Robot by Default will access Broker last 5 days of history with MQL4 functions.(most Brokers provide 2-5 days of history)
and will start to Trade.

Watch messages in Terminal/Experts window.

This Project is provided for Scientific/Research purposes. It needs to be run on Forex Demo account and if it is working on Forex
and there are those that claim that Forex is chaotic, unpredictable system, that means that this method will work on other real life
complex systems (somewhere in industry or in natural environment, where there are physical laws known governing those systems),
in which there are many variables depended on each other and there is need to predict future movement of those variables.