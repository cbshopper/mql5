#ifndef FILE_VALUES_PROVIDER
#define FILL_VALUES_PROVIDER

#include <time.h>
#include <string>
#include <vector>

using namespace std;

class CRow {
private:
	time_t m_RowDate;
	vector<double> m_ColumnsValues;

public:
	void Init(int am);

	time_t GetDate();

	void SetDate(time_t time);

	double GetColumnValue(int nr);

	void SetColumnValue(int nr, double val);
};

class CValuesProvider {
private:
	time_t m_Time;
	vector<string> m_ColumnsNames;
	vector<CRow> m_Rows;

public:
	void Init(string filename);

	void AssingCurrentTime(string time);

	void AddSecondsToCurrentTime(int amount);

	double ValueOfColumnAtCurrentTime(string column);

	double ValueOfColumnInSpecificTime(string column, string time);

	string ColumnName(int nr);

	int ColumnsTotal();
};
#endif