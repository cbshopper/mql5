/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_LOGGER
#define FILE_LOGGER

#include "Config.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/FileWriter.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/DateTime.h"

//+------------------------------------------------------------------+
class CLogger {
private:
	static IFileWriter Writer;
	static IFileWriter WriterSpecial;
	static IFileWriter WriterTrades;
	static IFileWriter WriterReverseTrades;
	static IFileWriter WriterModificators;
	static bool Initialized;

public:
	void static Init(IString &name)
	{
		if (!Initialized)
		{
			IString time = IDateTime::TimeCurrentAsString();

			time.StringReplace(".", "_");
			time.StringReplace(":", "_");
			time.StringReplace(" ", "_");

			IString nameW;

			nameW.AssignString(name + "_" + time + ".txt");
			Writer.Initialize(nameW);

			nameW.AssignString(IString("special") + "_" + time + ".txt");
			WriterSpecial.Initialize(nameW);

			nameW.AssignString(IString("trades") + "_" + time + ".txt");
			WriterTrades.Initialize(nameW);

			nameW.AssignString("reverse_trades.txt");
			WriterReverseTrades.Initialize(nameW);

			nameW.AssignString(IString("modificators") + "_" + time + ".txt");
			WriterModificators.Initialize(nameW);

			Initialized = true;
		}
	}

	void static WriteReverseTrades(bool reverse)
	{
		IString str;
		IString time(IDateTime::TimeCurrentAsString());

		WriterReverseTrades.Write(str + time + ", " + (reverse ? "true" : "false"));
	}

	bool static ReadLastReverseTrades()
	{
		IString last = WriterReverseTrades.ReadEndLine();
		IGenericObjectArray<IString> result;

		if (IString::AreEqual(last, IString()))
		{
			return false;
		}
		last.StringSplit(',', result);
		if (result.Size() > 0)
		{
			IString val((*(result.GetPointerToValue(1))));
			IString val2(val.StringTrimLeft());
			IString val3(val2.StringTrimRight());
			return (IString::AreEqual(val2, IString("true")) ? true : false);
		}
		else
		{
			return false;
		}
	}

#ifndef CPP

	void static Log(IString &msg)
	{
		IInteroperability::Print(msg);
		LogInFile(msg);
	}

	void static LogInFile(IString &msg)
	{
		IString time;

		time = IDateTime::TimeCurrentAsString();

		Writer.Write(time + ", " + msg);
	}

	void static HeavyLog(IString &msg)
	{
		if (CConfig::HeavyLoggingInFile)
		{
			LogInFile(msg);
		}
	}

	void static LogSpecial(IString &msg)
	{
		IString time;

		time = IDateTime::TimeCurrentAsString();

		WriterSpecial.Write(time + ", " + msg);
		Log(msg);
	}

	void static LogTrade(IString &msg)
	{
		IString time;

		time = IDateTime::TimeCurrentAsString();

		WriterTrades.Write(time + ", " + msg);
		Log(msg);
	}

	void static LogFromModificator(IString &msg)
	{
		IString time;

		time = IDateTime::TimeCurrentAsString();

		WriterModificators.Write(time + ", " + msg);
		Log(msg);
	}

#else

	void static Log(IString msg)
	{
		IInteroperability::Print(msg);
		LogInFile(msg);
	}

	void static LogInFile(IString msg)
	{
		IString time(IDateTime::TimeCurrentAsString());

		Writer.Write(time + ", " + msg);
	}

	void static HeavyLog(IString msg)
	{
		if (CConfig::HeavyLoggingInFile)
		{
			LogInFile(msg);
		}
	}

	void static LogSpecial(IString msg)
	{
		IString time(IDateTime::TimeCurrentAsString());

		WriterSpecial.Write(time + ", " + msg);
		Log(msg);
	}

	void static LogTrade(IString msg)
	{
		IString time(IDateTime::TimeCurrentAsString());

		WriterTrades.Write(time + ", " + msg);
		Log(msg);
	}

	void static LogFromModificator(IString msg)
	{
		IString time;

		time = IDateTime::TimeCurrentAsString();

		WriterModificators.Write(time + ", " + msg);
		Log(msg);
	}

#endif
};
IFileWriter CLogger::Writer;
IFileWriter CLogger::WriterSpecial;
IFileWriter CLogger::WriterTrades;
IFileWriter CLogger::WriterReverseTrades;
IFileWriter CLogger::WriterModificators;
bool CLogger::Initialized = false;
//+------------------------------------------------------------------+
#endif