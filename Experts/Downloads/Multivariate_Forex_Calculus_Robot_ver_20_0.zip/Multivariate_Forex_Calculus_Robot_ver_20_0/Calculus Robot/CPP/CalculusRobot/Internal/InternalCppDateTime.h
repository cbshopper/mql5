/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_INTERNAL_CPP_DATE_TIME
#define FILE_INTERNAL_CPP_DATE_TIME

#include "InternalCppString.h"
#include <time.h>

//+------------------------------------------------------------------+
class IDateTime {
private:
	time_t m_Time;

public:
	IDateTime();

	bool operator<(const IDateTime &other);

	bool operator>(const IDateTime &other);

	IDateTime(const IDateTime &other);
	
	IDateTime static TimeCurrent();

	IString static GetDay(IDateTime &time);

	IDateTime static AddMinute(IDateTime &time);

	IDateTime static AddMinutes(IDateTime &time, int minutes);
	
	IDateTime static AddSeconds(IDateTime &time, int seconds);
	
	int static MinutesDiff(IDateTime &before, IDateTime &after);

	IDateTime static MinusHours(IDateTime &time, int hoursAm);

	double static SecondsDiff(IDateTime &before, IDateTime &after);
	
	IString static FromSeconds(double seconds);

	IString static TimeCurrentAsString();
};
//+------------------------------------------------------------------+
#endif