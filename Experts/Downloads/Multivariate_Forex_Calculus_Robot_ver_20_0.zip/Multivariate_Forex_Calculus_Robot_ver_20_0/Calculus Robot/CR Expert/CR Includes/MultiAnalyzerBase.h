/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MULTI_ANALYZER_BASE
#define FILE_MULTI_ANALYZER_BASE

#include "Config.h"
#include "Values.h"
#include "Analyzer.h"
#include "CurrencyPairs.h"
#include "ValuesAnalyzers.h"
#include "CurrencyPair.h"
#include "PastPointsArray.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/GenericArray.h"
#include "../../Interoperability/GenericObjectArray.h"

//+------------------------------------------------------------------+
class CMultiAnalyzerBase{
    protected:
        static const int NOT_FOUND;
    
        CValues *values;
  
        IGenericArray<double> m_WasMinimumMaximumInForBuy;
        IGenericArray<double> m_WasMinimumMaximumInForSell;
        IGenericArray<double> m_WasMinimumMaximumOtherInForBuy;
        IGenericArray<double> m_WasMinimumMaximumOtherInForSell;

        IGenericObjectArray<CAnalyzer> m_AnalyzersForToBuy;
        IGenericObjectArray<CAnalyzer> m_AnalyzersForToSell;
        IGenericObjectArray<CAnalyzer> m_AnalyzersOtherForToBuy;
        IGenericObjectArray<CAnalyzer> m_AnalyzersOtherForToSell;

        IGenericObjectArray<CValuesAnalyzers> m_ValuesAnalyzersForToBuy;
        IGenericObjectArray<CValuesAnalyzers> m_ValuesAnalyzersForToSell;
        IGenericObjectArray<CValuesAnalyzers> m_ValuesAnalyzersOtherForToBuy;
        IGenericObjectArray<CValuesAnalyzers> m_ValuesAnalyzersOtherForToSell;

        CPastPointsArray m_PastPoints;
        
        CCurrencyPairs *m_Pairs;
        
        int m_DatesNr;
              
        void SetWasMMtoFalse()
        {
            for(int i=0;i<m_WasMinimumMaximumInForBuy.Size();i++)
            {
                m_WasMinimumMaximumInForBuy.SetValue(i, CAnalyzer::NO_RESULT);
            }
            for(int i=0;i<m_WasMinimumMaximumInForSell.Size();i++)
            {
                m_WasMinimumMaximumInForSell.SetValue(i, CAnalyzer::NO_RESULT);
            }
            for(int i=0;i<m_WasMinimumMaximumOtherInForBuy.Size();i++)
            {
                m_WasMinimumMaximumOtherInForBuy.SetValue(i, CAnalyzer::NO_RESULT);
            }
            for(int i=0;i<m_WasMinimumMaximumOtherInForSell.Size();i++)
            {
                m_WasMinimumMaximumOtherInForSell.SetValue(i, CAnalyzer::NO_RESULT);
            }
        }
        
        void Init(int dataNr)
        {
            m_WasMinimumMaximumInForBuy.Resize(0);
            m_WasMinimumMaximumInForSell.Resize(0);
            m_WasMinimumMaximumOtherInForBuy.Resize(0);
            m_WasMinimumMaximumOtherInForSell.Resize(0);
            m_AnalyzersForToBuy.Resize(0);
            m_AnalyzersForToSell.Resize(0);
            m_AnalyzersOtherForToBuy.Resize(0);
            m_AnalyzersOtherForToSell.Resize(0);
            m_ValuesAnalyzersForToBuy.Resize(0);
            m_ValuesAnalyzersForToSell.Resize(0);
            m_ValuesAnalyzersOtherForToBuy.Resize(0);
            m_ValuesAnalyzersOtherForToSell.Resize(0);
           
            m_WasMinimumMaximumInForBuy.Resize((*m_Pairs).AmountCurrencyPairsToBuy());
            m_WasMinimumMaximumInForSell.Resize((*m_Pairs).AmountCurrencyPairsToSell());
            m_WasMinimumMaximumOtherInForBuy.Resize((*m_Pairs).AmountOtherSymbolsToBuy());
            m_WasMinimumMaximumOtherInForSell.Resize((*m_Pairs).AmountOtherSymbolsToSell());
            m_AnalyzersForToBuy.Resize((*m_Pairs).AmountCurrencyPairsToBuy());
            m_AnalyzersForToSell.Resize((*m_Pairs).AmountCurrencyPairsToSell());
            m_AnalyzersOtherForToBuy.Resize((*m_Pairs).AmountOtherSymbolsToBuy());
            m_AnalyzersOtherForToSell.Resize((*m_Pairs).AmountOtherSymbolsToSell());
            m_ValuesAnalyzersForToBuy.Resize((*m_Pairs).AmountCurrencyPairsToBuy());
            m_ValuesAnalyzersForToSell.Resize((*m_Pairs).AmountCurrencyPairsToSell());
            m_ValuesAnalyzersOtherForToBuy.Resize((*m_Pairs).AmountOtherSymbolsToBuy());
            m_ValuesAnalyzersOtherForToSell.Resize((*m_Pairs).AmountOtherSymbolsToSell());
                          
            IInteroperability::RefreshRates();  
                      
            double val;
			IDateTime time((*values).ReturnDateTimeOfPastNr(dataNr));


            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToBuy();i++)
            {
			    val = (*values).ReturnPastValueNrToBuy(dataNr, i);
                (*(m_AnalyzersForToBuy.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, time, dataNr);
            }
            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToSell();i++)
            {
                val = (*values).ReturnPastValueNrToSell(dataNr, i);
                (*(m_AnalyzersForToSell.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, time, dataNr);
            }
            for(int i=0;i<(*m_Pairs).AmountOtherSymbolsToBuy();i++)
            {
                val = (*values).ReturnOtherPastValueNrToBuy(dataNr, i);
                (*(m_AnalyzersOtherForToBuy.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, time, dataNr);
            }
            for(int i=0;i<(*m_Pairs).AmountOtherSymbolsToSell();i++)
            {
                val = (*values).ReturnOtherPastValueNrToSell(dataNr, i);
                (*(m_AnalyzersOtherForToSell.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, time, dataNr);
            }
            m_PastPoints.Reset();
        } 

		IGenericArray<double>* WasMinimumMaximum(bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return &m_WasMinimumMaximumInForBuy;
				}
				else
				{
					return &m_WasMinimumMaximumInForSell;
				}
			}
			else
			{
				if (Buy)
				{
					return &m_WasMinimumMaximumOtherInForBuy;
				}
				else
				{
					return &m_WasMinimumMaximumOtherInForSell;
				}
			}
		}

		IGenericObjectArray<CAnalyzer>* Analyzers(bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return &m_AnalyzersForToBuy;
				}
				else
				{
					return &m_AnalyzersForToSell;
				}
			}
			else
			{
				if (Buy)
				{
					return &m_AnalyzersOtherForToBuy;
				}
				else
				{
					return &m_AnalyzersOtherForToSell;
				}
			}
		}

		IGenericObjectArray<CValuesAnalyzers>* ValuesAnalyzers(bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return &m_ValuesAnalyzersForToBuy;
				}
				else
				{
					return &m_ValuesAnalyzersForToSell;
				}
			}
			else
			{
				if (Buy)
				{
					return &m_ValuesAnalyzersOtherForToBuy;
				}
				else
				{
					return &m_ValuesAnalyzersOtherForToSell;
				}
			}
		}

    public: 
        void PreInit(CCurrencyPairs &pairs)
        {
            m_DatesNr = 0;
            m_Pairs = &pairs;
        }
        
        int AmountToBuy()
        {
            return (*m_Pairs).AmountCurrencyPairsToBuy();
        }

        int AmountToSell()
        {
            return (*m_Pairs).AmountCurrencyPairsToSell();
        }
        
        int AmountOtherToBuy()
        {
            return (*m_Pairs).AmountOtherSymbolsToBuy();
        }
        
        int AmountOtherToSell()
        {
            return (*m_Pairs).AmountOtherSymbolsToSell();
        }
        
        void SetValues(CValues &_values)
        {
            values = &_values;
        }

        void Log()
        {
            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToBuy();i++)
            {
				IString pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

                (*(m_AnalyzersForToBuy.GetPointerToValue(i))).LogCount(pair);
                (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).Log(pair);
            }
            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToSell();i++)
            {
				IString pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

                (*(m_AnalyzersForToSell.GetPointerToValue(i))).LogCount(pair);
                (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).Log(pair);
            }
			for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
			{
				IString pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

				(*(m_AnalyzersOtherForToBuy.GetPointerToValue(i))).LogCount(pair);
				(*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).Log(pair);
			}
			for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
			{
				IString pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

				(*(m_AnalyzersOtherForToSell.GetPointerToValue(i))).LogCount(pair);
				(*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).Log(pair);
			}
		}
};
const int CMultiAnalyzerBase::NOT_FOUND = -1;
//+------------------------------------------------------------------+
#endif