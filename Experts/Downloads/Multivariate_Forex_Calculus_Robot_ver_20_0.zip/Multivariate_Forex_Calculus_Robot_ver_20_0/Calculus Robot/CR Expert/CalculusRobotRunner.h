/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_CALCULUS_ROBOT_RUNNER
#define FILE_CALCULUS_ROBOT_RUNNER

#include "CalculusRobotExpert.h"
#include "../Interoperability/Interoperability.h"
#include "CR Includes/Open Trades Modifiers/OpenTradesModifiersRunner.h"

//+------------------------------------------------------------------+
class CCalculusRobotRunner {
private:
	CCalculusRobotExpert *Expert;
	CParams Params;
	CCurrencyPairs Pairs;
	CMultiAnalyzerProcess AnalyzerProcess;
	COpenTradesModifiersRunner *ModifiersRunner;

public:
	bool Init()
	{
		IInteroperability::Activate();

		if (!CCalculusRobotExpert::CheckLeverage())
		{
			return false;
		}

		Expert = new CCalculusRobotExpert();
		(*Expert).SetTimer();

		if (CConfig::ConsiderAccountCurrency)
		{
			IString curr(IInteroperability::AccountCurrency());

			Pairs.Init(curr);
		}
		else
		{
			IString curr("000");

			Pairs.Init(curr);
		}

		(*Expert).SetParams(Params, Pairs);

		if (!(*Expert).GetValues())
		{
			CLogger::Log(IString("Can't get history. Re-run Robot."));
			return false;
		}
		else
		{
			IDateTime time(IDateTime::TimeCurrent());
			CValues *values = (*Expert).ReturnValues();

			AnalyzerProcess.PreInit(Pairs);
			AnalyzerProcess.SetValues(*values);
			AnalyzerProcess.Init(Pairs, time, Params);
			(*Expert).AssignAnalyzerProcess(AnalyzerProcess);
			(*Expert).CheckHistory();
			(*Expert).SetInitialization();
		}

		Params.ReverseTrades = CLogger::ReadLastReverseTrades();
		(*Expert).DeterminePastReverseTrades();

		ModifiersRunner = new COpenTradesModifiersRunner();
		(*ModifiersRunner).Init();

		return true;
	}

	void OnInterval()
	{
		if (Params.IfPerformReverseTradesCheck())
		{
			(*Expert).DeterminePastReverseTrades();
			Params.ZeroFinds();
		}
		if ((*Expert).CheckForInitialization())
		{
			delete Expert;
			Expert = new CCalculusRobotExpert();

			(*Expert).SetParams(Params, Pairs);
			AnalyzerProcess.ZeroSearchingProfit();

			if (!(*Expert).GetValues())
			{
				CLogger::Log(IString("Can't get history. Re-run Robot."));
			}
			(*Expert).AssignAnalyzerProcess(AnalyzerProcess);
			(*Expert).CheckHistory();
			(*Expert).SetInitialization();
		}
		else
		{
			(*ModifiersRunner).OnInterval();
			(*Expert).DoTrading();
		}
	}

	void DeInit()
	{
		if (Expert != NULL)
		{
			(*Expert).KillTimer();
			delete Expert;
			delete ModifiersRunner;
		}
	}
};
//+------------------------------------------------------------------+
#endif