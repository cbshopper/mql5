/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_TRADING
#define FILE_TRADING

#include "Logger.h"
#include "Values.h"
#include "Config.h"
#include "CurrencyPairs.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/DateTime.h" 

//+------------------------------------------------------------------+
class CTrading{
    private:
        static int MicroLotsAmount()
        {
            int amount = (int)(((IInteroperability::AccountBalance() * IInteroperability::AccountLeverage() * CConfig::PercentOfBalanceToTrade) / CConfig::MaxVolume));
            
            if(amount > CConfig::MaxAmount)
            {
                return CConfig::MaxAmount;
            }
            else
            {
                return amount;
            }
        }
        
        static int SingleMicroLotsAmount()
        {
            int microLotsAmount = MicroLotsAmount();
            
            if(microLotsAmount <= CConfig::SingleTradesAmount)
            {
                if(microLotsAmount > 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return (int)((double)(microLotsAmount)/(double)(CConfig::SingleTradesAmount));
            }
        }
        
        static void SendOrder(IString &symbol, double price, bool buy, double takeProfit, double stopLoss)
        {
            IString type;
         
            price = IInteroperability::NormalizeDouble(price, IInteroperability::Digits());
            takeProfit = IInteroperability::NormalizeDouble(takeProfit, IInteroperability::Digits());
            stopLoss = IInteroperability::NormalizeDouble(stopLoss, IInteroperability::Digits());
           
            if(buy)
            {
                type.AssignString("Buy");                
            }
            else
            {
                type.AssignString("Sell");
            }
            
            long nr = 0;
            
            if(IsBiggerSlipPage(price))
            {
                if(CConfig::ExecuteTrades)
                {
                    if(CCurrencyPairs::IsCurrencyPair(symbol))
                    {
                        nr = IInteroperability::OrderSend(symbol, buy, CConfig::LotSize, price, CConfig::SlipPage, stopLoss, takeProfit);
                    }
                    else
                    {
                        nr = IInteroperability::OrderSend(symbol, buy, CConfig::LotSize, price, CConfig::SlipPage, stopLoss, takeProfit);
                    }
                }
            }
            else
            {
                if(CConfig::ExecuteTrades)
                {
                    if(CCurrencyPairs::IsCurrencyPair(symbol))
                    {
                        nr = IInteroperability::OrderSend(symbol, buy, CConfig::LotSize, price, CConfig::SlipPage, stopLoss, takeProfit);
                    }
                    else
                    {
                        nr = IInteroperability::OrderSend(symbol, buy, CConfig::LotSize, price, CConfig::SlipPage, stopLoss, takeProfit);
                    }
                }
            }
            
            if(nr>=0)
            {  
				IString msg("Order Send, Pair : ");

				msg += (symbol + ", Price : " + IInteroperability::DoubleToString(price) + ", Type : " + type + ", Take Profit : " + IInteroperability::DoubleToString(takeProfit) + ", Stop Loss : " + IInteroperability::DoubleToString(stopLoss));
                CLogger::LogTrade(msg);  
            }
            else
            {
				IString msg("Error, Order Send, Pair : ");

				msg += (symbol + ", Price : " + IInteroperability::DoubleToString(price) + ", Type : " + type + ", Take Profit : " + IInteroperability::DoubleToString(takeProfit) + ", Stop Loss : " + IInteroperability::DoubleToString(stopLoss));
                CLogger::LogTrade(msg);

				IString error("Error : ");

				error += (IInteroperability::IntegerToString(IInteroperability::GetLastError()));
			
                CLogger::LogTrade(error);
            }
        }
        
        static bool IsBiggerSlipPage(double price)
        {
            return price >= CConfig::BiggerSlipPagePriceValue;
        }
        
        static void Log(IString &symbol)
        {
            IDateTime now = IDateTime::TimeCurrent();

            CLogger::LogSpecial(IString("Log Symbol : ") + symbol + ", iHigh : " + IInteroperability::DoubleToString(CValues::GetPriceAtTimeHigh(symbol, now)) + ", iLow : " + IInteroperability::DoubleToString(CValues::GetPriceAtTime(symbol,now)) + ", Sell : " + IInteroperability::DoubleToString(CValues::SellPrice(symbol)) + ", Buy : " + IInteroperability::DoubleToString(CValues::BuyPrice(symbol)) + ", Spread : " + IInteroperability::DoubleToString(CValues::Spread(symbol)));
        }
        
		unsigned long m_Ticket;
		int m_TicketNr;

    public:
		void OrderSelect(int nr)
		{
			m_TicketNr = nr;
			m_Ticket = IInteroperability::HistoryOrderTicket(nr);
		}

		double OrderOpenPrice()
		{
			return IInteroperability::OrderOpenPrice(m_Ticket);
		}

		double OrderPrice()
		{
			return IInteroperability::OrderCurrentPrice(m_Ticket);
		}

		double OrderProfit()
		{
			return IInteroperability::OrderProfit(m_Ticket);
		}

		double OrderTakeProfit()
		{
			return IInteroperability::OrderTakeProfit(m_Ticket);
		}

		double OrderStopLoss()
		{
			return IInteroperability::OrderStopLoss(m_Ticket);
		}
		
        static double LastPeriodClosedSuccessfullTradesAmount(IDateTime &date)
        {
            int total = IInteroperability::OrdersHistoryTotal();
            int all = 0, positive = 0;
            IDateTime dateOrder;
            unsigned long ticket;
           
            for(int i=0; i < total ;i++)
            {
                ticket = IInteroperability::HistoryOrderTicket(i);
                if(IInteroperability::OrderSelect(i, ticket)==true)
                {
                    IInteroperability::OrderOpenTime(ticket, dateOrder);
                    if(dateOrder > date)
                    {
                        all++;
                        if(IInteroperability::OrderProfit(ticket) > 0.0)
                        {
                            positive++;
                        }
                    }
                }
            }
            if(all == 0)
            {
                return 0.0;
            }
            return (double)(positive)/(double)(all);
        }
   
        static bool ProceedWithSearching(CCurrencyPairs &pairs, bool other, int nr, bool buy, double upperLimit, double lowerLimit)
        {
            double takeProfit;
            double stopLoss;
            double price;
            IString symbol;
            
            if(other)
            {
                if(buy)
                {
                    symbol.AssignString(pairs.ReturnOtherSymbolToBuyNr(nr));
                }
                else
                {
                    symbol.AssignString(pairs.ReturnOtherSymbolToSellNr(nr));
                }
            }
            else
            {
                if(buy)
                {
                    symbol.AssignString(pairs.ReturnCurrencyPairToBuyNr(nr));
                }
                else
                {
                    symbol.AssignString(pairs.ReturnCurrencyPairToSellNr(nr));
                }
            }
            
            if(buy)
            {
                price = CValues::BuyPrice(symbol);
                takeProfit = upperLimit;
                stopLoss = lowerLimit;
            }
            else
            {
                price = CValues::SellPrice(symbol);         
                takeProfit = lowerLimit;
                stopLoss = upperLimit;
            }         
            if(buy)
            {
                if((takeProfit - price) * CConfig::TakeProfitPercentForStopLoss * CConfig::TakeProfitPercentForStopLossToIgnore < (price - stopLoss))
                {
                     return false;
                }
            }
            else
            {
                if((price - takeProfit) * CConfig::TakeProfitPercentForStopLoss * CConfig::TakeProfitPercentForStopLossToIgnore < (stopLoss - price))
                {
                     return false;
                }
            }
            return true;
        }
    
        static void SendOrder(CCurrencyPairs &pairs, bool other, int nr, bool buy, double upperLimit, double lowerLimit, bool reverse, bool reverseFromPast)
        {
            double takeProfit;
            double stopLoss;
            double price;
            IString symbol;
            double spread = -1.0;
            
            if(reverse)
            {
                buy = !buy;
            }
            
            if(reverseFromPast)
            {
                buy = !buy;            
            }
            
            if(CConfig::ReverseTrades)
            {
                buy = !buy;
            }
            
            if(other)
            {
                if(buy)
                {
                    symbol.AssignString(pairs.ReturnOtherSymbolToBuyNr(nr));
                }
                else
                {
                    symbol.AssignString(pairs.ReturnOtherSymbolToSellNr(nr));
                }
            }
            else
            {
                if(buy)
                {
                    symbol.AssignString(pairs.ReturnCurrencyPairToBuyNr(nr));
                }
                else
                {
                    symbol.AssignString(pairs.ReturnCurrencyPairToSellNr(nr));
                }
            }
            
            if(buy)
            {
                price = CValues::BuyPrice(symbol);
                //spread = CConfig::SpreadMulti * CValues::Spread(symbol);
                takeProfit = upperLimit;// - spread;
                stopLoss = lowerLimit;// - spread;
            }
            else
            {
                price = CValues::SellPrice(symbol);         
                //spread = CConfig::SpreadMulti * CValues::Spread(symbol);
                takeProfit = lowerLimit;// + spread;
                stopLoss = upperLimit;// + spread;
            }
            
            CLogger::LogSpecial(IString("Symbol : ") + symbol + ", Price : " + IInteroperability::DoubleToString(price) + ", upperLimit : " + IInteroperability::DoubleToString(upperLimit) + ", LowerLimit : " + IInteroperability::DoubleToString(lowerLimit));
            Log(symbol);
            SendOrder(symbol, price, buy, takeProfit, stopLoss);
        }
};
//+------------------------------------------------------------------+
#endif