/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_CURRENCY_PAIRS
#define FILE_CURRENCY_PAIRS

#include "Config.h"
#include "Math.h"
#include "CurrencyPair.h"
#include "Logger.h"
#include "Learning.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/GenericArray.h"
#include "../../Interoperability/String.h"

//+------------------------------------------------------------------+
class CCurrencyPairMulti{
    private:
        int SucceddedInRow;
        int FailedInRow;

    public:
        double BiggestValue;
        double StopLossMultiForBiggestValue;
        double PossibleProfitMultiForBiggestValue;
        double StopLossMulti;
        double PossibleProfitMulti;
        double ProportionalBiggestValue;
        bool Learnable;
        double ProfitMinusSpread;
        bool IsTradable;
        CLearning Learning;
        bool ReverseTrades;
        
        int GainProfitsAmount;
        int LooseProfitsAmount;
        
        void SetToBiggest()
        {
            StopLossMulti = StopLossMultiForBiggestValue;
            PossibleProfitMulti = PossibleProfitMultiForBiggestValue;
        }
        
        CCurrencyPairMulti()
        {
            BiggestValue = -10.0;
            StopLossMultiForBiggestValue = CConfig::StopLossMultiMin;
            PossibleProfitMultiForBiggestValue = CConfig::PossibleProfitMultiMin;
            StopLossMulti = CConfig::StopLossMultiMin;
            PossibleProfitMulti = CConfig::PossibleProfitMultiMin;
            ReverseTrades = false;
            SucceddedInRow = 0;
            FailedInRow = 0;
        }    
        
        void SetSuccedded(IString &symbol, bool success)
        {
            if(success)
            {
                SucceddedInRow++;
                FailedInRow = 0;
            }
            else
            {
                FailedInRow++;  
                SucceddedInRow = 0; 
            }
            if(SucceddedInRow >= CConfig::SuccededInRowSingle)
            {
                ReverseTrades = false;
                CLogger::LogSpecial(IString("Reverse Trades for : ") + symbol + (ReverseTrades ? "true" : "false"));
            }
            else if(FailedInRow >= CConfig::FailedInRowSingle)
            {
                ReverseTrades = true;
                CLogger::LogSpecial(IString("Reverse Trades for : ") + symbol + (ReverseTrades ? "true" : "false"));
            }
        }
        
        void CalculateProprtional(IString &symbol, IDateTime& now)
        {
            CCurrencyPair pair;
            
            pair.Profit = BiggestValue;
            pair.Symbol.AssignString(symbol);
            
            pair.CalculateProportionalProfit(now);
            
            ProportionalBiggestValue = pair.ProportionalProfit;
        }
};
//+------------------------------------------------------------------+
class CCurrencyPairs{
    private:
        IGenericObjectArray<IString> m_CurrencyPairsToBuy;
        IGenericObjectArray<IString> m_CurrencyPairsToSell;
        IGenericObjectArray<CCurrencyPairMulti> m_CurrencyPairsToBuyMulti;
        IGenericObjectArray<CCurrencyPairMulti> m_CurrencyPairsToSellMulti;
        IGenericObjectArray<IString> m_OtherSymbolsToBuy;
        IGenericObjectArray<IString> m_OtherSymbolsToSell;
        IGenericObjectArray<CCurrencyPairMulti> m_OtherSymbolsToBuyMulti;
        IGenericObjectArray<CCurrencyPairMulti> m_OtherSymbolsToSellMulti;
		int m_Tradable;

        static bool IsCurrencyPairToBuy(IString &currency, IString &currencyPair)
        {
            if(currencyPair.StringLen() >= 6)
            {
                return IString::AreEqual(currencyPair.SubString(3, 3), currency);
            }
            return false;
        }
        
        static bool IsCurrencyPairToSell(IString &currency, IString &currencyPair)
        {
            if(currencyPair.StringLen() >= 6)
            {
                return IString::AreEqual(currencyPair.SubString(0, 3), currency);
            }
            return false;
        }
    
        int CountCurrencyPairsToBuy(IString &currency)
        {
            int am = 0;
            
            for(int i=0;i<IInteroperability::SymbolsTotal(true);i++)
            {
				IString symbol(IInteroperability::SymbolName(i, true));

                if(IsCurrencyPairToBuy(currency, symbol) && (IsCurrencyPair(symbol) || !CConfig::UseOnlyCurrencyPairs))
                {
                    am++;
                }
            }
            return am;
        }

        int CountCurrencyPairsToSell(IString &currency)
        {
            int am = 0;
            
            for(int i=0;i<IInteroperability::SymbolsTotal(true);i++)
            {
				IString symbol(IInteroperability::SymbolName(i, true));

                if(IsCurrencyPairToSell(currency, symbol) && (IsCurrencyPair(symbol) || !CConfig::UseOnlyCurrencyPairs))
                {
                    am++;
                }
            }
            return am;
        }
        
        int CountOtherSymbolsToBuyToSell(IString &currency)
        {
            int am = 0;
            
            for(int i=0;i<IInteroperability::SymbolsTotal(true);i++)
            {
				IString symbol(IInteroperability::SymbolName(i, true));

                if(IsCurrencyPair(symbol))
                {
                    am++;
                }
            }
            return IInteroperability::SymbolsTotal(true) - CountCurrencyPairsToBuy(currency) - CountCurrencyPairsToSell(currency);
        }
        
        void LimitCurrencyPairs(IGenericObjectArray<IString> &pairs, IGenericArray<bool> &present)
        {
            int am = 0;
            
            for(int i=0;i<present.Size();i++)
            {
                if(present.GetValue(i))
                {
                    am++;
                }
            }
            
            IGenericObjectArray<IString> symbols;
            int nr = 0;
            
            symbols.Resize(am);
            for(int i=0;i<pairs.Size();i++)
            {
                if(present.GetValue(i))
                {
                    symbols.SetValue(nr, (*(pairs.GetPointerToValue(i))));
                    nr++;
                }                
            }
            pairs.Resize(symbols.Size());
            for(int i=0;i<symbols.Size();i++)
            {
                pairs.SetValue(i, (*(symbols.GetPointerToValue(i))));
            }            
        }
    
		double ReturnUpperLimitToBuy(double val, double diff, int SymbolNr)
		{
			return val + (*(ReturnOtherMultiToBuyNr(SymbolNr))).PossibleProfitMulti * diff * CConfig::MultiPercent;
		}

		double ReturnLowerLimitToBuy(double val, double diff, int SymbolNr)
		{
			return val - (*(ReturnOtherMultiToBuyNr(SymbolNr))).StopLossMulti * diff * CConfig::MultiPercent;
		}

		double ReturnUpperLimitToSell(double val, double diff, int SymbolNr)
		{
			return val + (*(ReturnMultiToSellNr(SymbolNr))).StopLossMulti * diff * CConfig::MultiPercent;
		}

		double ReturnLowerLimitToSell(double val, double diff, int SymbolNr)
		{
			return val - (*(ReturnMultiToSellNr(SymbolNr))).PossibleProfitMulti * diff * CConfig::MultiPercent;
		}

		double ReturnUpperLimitOtherToBuy(double val, double diff, int SymbolNr)
		{
			return val + (*(ReturnOtherMultiToBuyNr(SymbolNr))).PossibleProfitMulti * diff * CConfig::MultiPercent;
		}

		double ReturnLowerLimitOtherToBuy(double val, double diff, int SymbolNr)
		{
			return val - (*(ReturnOtherMultiToBuyNr(SymbolNr))).StopLossMulti * diff * CConfig::MultiPercent;
		}

		double ReturnUpperLimitOtherToSell(double val, double diff, int SymbolNr)
		{
			return val + (*(ReturnOtherMultiToSellNr(SymbolNr))).StopLossMulti * diff * CConfig::MultiPercent;
		}

		double ReturnLowerLimitOtherToSell(double val, double diff, int SymbolNr)
		{
			return val - (*(ReturnOtherMultiToSellNr(SymbolNr))).PossibleProfitMulti * diff * CConfig::MultiPercent;
		}

        CCurrencyPairMulti* ReturnMultiToBuyNr(int nr)
        {
            return m_CurrencyPairsToBuyMulti.GetPointerToValue(nr);
        }
        
        CCurrencyPairMulti* ReturnMultiToSellNr(int nr)
        {
            return m_CurrencyPairsToSellMulti.GetPointerToValue(nr);
        }
        
        CCurrencyPairMulti* ReturnOtherMultiToBuyNr(int nr)
        {
            return m_OtherSymbolsToBuyMulti.GetPointerToValue(nr);
        }
    
        CCurrencyPairMulti* ReturnOtherMultiToSellNr(int nr)
        {
            return m_OtherSymbolsToSellMulti.GetPointerToValue(nr);
        }

		bool IsCurrencyPairToBuyPredictedProfitable(int nr)
		{
			return (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(nr))).IsTradable;
		}

		bool IsCurrencyPairToSellPredictedProfitable(int nr)
		{
			return (*(m_CurrencyPairsToSellMulti.GetPointerToValue(nr))).IsTradable;
		}

		bool IsOtherSymbolToBuyPredictedProfitable(int nr)
		{
			return (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(nr))).IsTradable;
		}

		bool IsOtherSymbolToSellPredictedProfitable(int nr)
		{
			return (*(m_OtherSymbolsToSellMulti.GetPointerToValue(nr))).IsTradable;
		}

    public:         
		bool IsSymbolPredictedProfitable(int nr, bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return IsCurrencyPairToBuyPredictedProfitable(nr);
				}
				else
				{
					return IsCurrencyPairToSellPredictedProfitable(nr);
				}
			}
			else
			{
				if (Buy)
				{
					return IsOtherSymbolToBuyPredictedProfitable(nr);
				}
				else
				{
					return IsOtherSymbolToSellPredictedProfitable(nr);
				}
			}
		}
		
		CCurrencyPairMulti* ReturnMultiTo(int nr, bool Symbol, bool Buy)
        {
            if(Symbol)
            {
                if(Buy)
                {
                    return ReturnMultiToBuyNr(nr);
                }
                else
                {
                    return ReturnMultiToSellNr(nr);
                }
            }
            else
            {
                if(Buy)
                {
                    return ReturnOtherMultiToBuyNr(nr);
                }
                else
                {
                    return ReturnOtherMultiToSellNr(nr);
                }
            }
        }
    
        bool TradablePeriod()
        {
			return m_Tradable >= CConfig::MinTradableSymbols;
        }
        
		double ReturnLowerLimit(double val, double diff, int SymbolNr, bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return ReturnLowerLimitToBuy(val, diff, SymbolNr);
				}
				else
				{
					return ReturnLowerLimitToSell(val, diff, SymbolNr);
				}
			}
			else
			{
				if (Buy)
				{
					return ReturnLowerLimitOtherToBuy(val, diff, SymbolNr);
				}
				else
				{
					return ReturnLowerLimitOtherToSell(val, diff, SymbolNr);
				}
			}
		}

		double ReturnUpperLimit(double val, double diff, int SymbolNr, bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return ReturnUpperLimitToBuy(val, diff, SymbolNr);
				}
				else
				{
					return ReturnUpperLimitToSell(val, diff, SymbolNr);
				}
			}
			else
			{
				if (Buy)
				{
					return ReturnUpperLimitOtherToBuy(val, diff, SymbolNr);
				}
				else
				{
					return ReturnUpperLimitOtherToSell(val, diff, SymbolNr);
				}
			}
		}

        void Init(IString &currency)
        {
            int posBuy = 0;
            int posSell = 0;
            int posOther = 0;
            IString symbol;
        
            m_CurrencyPairsToBuy.Resize(CountCurrencyPairsToBuy(currency));
            m_CurrencyPairsToSell.Resize(CountCurrencyPairsToSell(currency));
            m_CurrencyPairsToBuyMulti.Resize(m_CurrencyPairsToBuy.Size());
            m_CurrencyPairsToSellMulti.Resize(m_CurrencyPairsToSell.Size());
            m_OtherSymbolsToBuy.Resize(CountOtherSymbolsToBuyToSell(currency));
            m_OtherSymbolsToSell.Resize(m_OtherSymbolsToBuy.Size());
            m_OtherSymbolsToBuyMulti.Resize(m_OtherSymbolsToBuy.Size());
            m_OtherSymbolsToSellMulti.Resize(m_OtherSymbolsToBuy.Size());
                  
            for(int i=0;i< IInteroperability::SymbolsTotal(true);i++)
            {
                symbol = IInteroperability::SymbolName(i, true);
                if(IsCurrencyPairToBuy(currency, symbol) && (IsCurrencyPair(symbol) || !CConfig::UseOnlyCurrencyPairs))
                {
                    m_CurrencyPairsToBuy.SetValue(posBuy, symbol);
                    posBuy++;
                }
                else if(IsCurrencyPairToSell(currency, symbol) && (IsCurrencyPair(symbol) || !CConfig::UseOnlyCurrencyPairs))
                {
                    m_CurrencyPairsToSell.SetValue(posSell, symbol);
                    posSell++;
                }
                else if((IsCurrencyPair(symbol) || !CConfig::UseOnlyCurrencyPairs))
                {                
                    m_OtherSymbolsToBuy.SetValue(posOther, symbol);
                    m_OtherSymbolsToSell.SetValue(posOther, symbol);
                    posOther++;
                }                  
            }
        }
        
        void DetermineTradable()
        {
            IGenericArray<double> values;
            IGenericArray<int> order;
            IDateTime now = IDateTime::TimeCurrent();
			
            values.Resize(m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + m_OtherSymbolsToBuy.Size() + m_OtherSymbolsToSell.Size());
            for(int i=0;i<m_CurrencyPairsToBuy.Size();i++)
            {
                (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).CalculateProprtional((*(m_CurrencyPairsToBuy.GetPointerToValue(i))), now);
                if((*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).LooseProfitsAmount!=0)
                {
                    values.SetValue(i, (double)(*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).GainProfitsAmount/(double)(*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).LooseProfitsAmount);
                }
                else
                {
                    values.SetValue(i, (double)(*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).GainProfitsAmount);
                }
            }
            for(int i=0;i<m_CurrencyPairsToSell.Size();i++)
            {
                (*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).CalculateProprtional((*(m_CurrencyPairsToSell.GetPointerToValue(i))), now);
                if((*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).LooseProfitsAmount!=0)
                {
                    values.SetValue(m_CurrencyPairsToBuy.Size() + i, (double)(*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).GainProfitsAmount/(double)(*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).LooseProfitsAmount);
                }
                else
                {
                    values.SetValue(m_CurrencyPairsToBuy.Size() + i, (double)(*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).GainProfitsAmount);
                }
            }
            for(int i=0;i<m_OtherSymbolsToBuy.Size();i++)
            {
                (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).CalculateProprtional((*(m_OtherSymbolsToBuy.GetPointerToValue(i))), now);
                if((*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).LooseProfitsAmount!=0)
                {
                    values.SetValue(m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + i, (double)(*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).GainProfitsAmount/(double)(*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).LooseProfitsAmount);
                }
                else
                {
                    values.SetValue(m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + i, (double)(*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).GainProfitsAmount);
                }
            }
            for(int i=0;i<m_OtherSymbolsToSell.Size();i++)
            {
                (*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).CalculateProprtional((*(m_OtherSymbolsToSell.GetPointerToValue(i))), now);
                if((*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).LooseProfitsAmount!=0)
                {
                    values.SetValue(m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + m_OtherSymbolsToBuy.Size() + i, (double)(*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).GainProfitsAmount/(double)(*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).LooseProfitsAmount);
                }
                else
                {
                    values.SetValue(m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + m_OtherSymbolsToBuy.Size() + i, (double)(*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).GainProfitsAmount);
                }
            }
            CMath::DetermineOrder(values, order);
            for(int i=0;i<m_CurrencyPairsToBuy.Size();i++)
            {
                (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).IsTradable = false;
                (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).Learnable = false;
            }
            for(int i=0;i<m_CurrencyPairsToSell.Size();i++)
            {
                (*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).IsTradable = false;
                (*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).Learnable = false;
            }
            for(int i=0;i<m_OtherSymbolsToBuy.Size();i++)
            {
                (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).IsTradable = false;
                (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).Learnable = false;
            }
            for(int i=0;i<m_OtherSymbolsToSell.Size();i++)
            {
                (*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).IsTradable = false;
                (*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).Learnable = false;
            }
            
            IString msg("Symbols to Trade : ");
            int learnableAmount = 0;
            
            for(int i=0;i<values.Size() * CConfig::PercentOfTopCurrenciesToLearn;i++)
            {
                if(order.GetValue(i) < m_CurrencyPairsToBuy.Size())
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(order.GetValue(i)))).ProportionalBiggestValue > 0.0 && (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(order.GetValue(i)))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(order.GetValue(i)))).Learnable = true;
                        learnableAmount++;
                    }
                }
                else if(order.GetValue(i) >= m_CurrencyPairsToBuy.Size() && order.GetValue(i) < m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size())
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).ProportionalBiggestValue > 0.0 && (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).Learnable = true;
                        learnableAmount++;
                    }
                }
                else if(order.GetValue(i) >= m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() && order.GetValue(i) < m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + m_OtherSymbolsToBuy.Size())
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).ProportionalBiggestValue > 0.0 && (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).Learnable = true;
                        learnableAmount++;
                    }                
                }
                else
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).ProportionalBiggestValue > 0.0 && (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).Learnable = true;
                        learnableAmount++;
                    }
                }
            }            
            
            int maxTradableAchived = 0;
            int maxTradable = (int)(learnableAmount * CConfig::TradableOfLearnedPercent);
            
            for(int i=0;i<values.Size() * CConfig::PercentOfTopCurrenciesToLearn;i++)
            {
                if(order.GetValue(i) < m_CurrencyPairsToBuy.Size())
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(order.GetValue(i)))).ProportionalBiggestValue > 0.0 && (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(order.GetValue(i)))).ProfitMinusSpread > 0.0)
                    {
                        if(maxTradableAchived<maxTradable)
                        {
                            maxTradableAchived++;
                            (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(order.GetValue(i)))).IsTradable = true;
                            msg += ", Selected : ";
                            msg += *(m_CurrencyPairsToBuy.GetPointerToValue(order.GetValue(i)));
                            msg += ":";
                            msg += IInteroperability::DoubleToString(values.GetValue(order.GetValue(i)));
                        }
                    }
                }
                else if(order.GetValue(i) >= m_CurrencyPairsToBuy.Size() && order.GetValue(i) < m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size())
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).ProportionalBiggestValue > 0.0 && (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).Learnable = true;
                        if(maxTradableAchived<maxTradable)
                        {
                            maxTradableAchived++;
                            (*(m_CurrencyPairsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()))).IsTradable = true;
                            msg += ", Selected : ";
                            msg += *(m_CurrencyPairsToSell.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size()));
                            msg += ":";
                            msg += IInteroperability::DoubleToString(values.GetValue(order.GetValue(i)));
                        }
                    }
                }
                else if(order.GetValue(i) >= m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() && order.GetValue(i) < m_CurrencyPairsToBuy.Size() + m_CurrencyPairsToSell.Size() + m_OtherSymbolsToBuy.Size())
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).ProportionalBiggestValue > 0.0 && (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).Learnable = true;
                        if(maxTradableAchived<maxTradable)
                        {
                            maxTradableAchived++;
                            (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()))).IsTradable = true;
                            msg += ", Selected : ";
                            msg += *(m_OtherSymbolsToBuy.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size()));
                            msg += ":";
                            msg += IInteroperability::DoubleToString(values.GetValue(order.GetValue(i)));                        
                        }
                    }                
                }
                else
                {
                    if(values.GetValue(order.GetValue(i)) >= CConfig::GainsMinPercentage && (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).ProportionalBiggestValue > 0.0 && (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).ProfitMinusSpread > 0.0)
                    {
                        (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).Learnable = true;
                        if(maxTradableAchived<maxTradable)
                        {
                            maxTradableAchived++;
                            (*(m_OtherSymbolsToSellMulti.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()))).IsTradable = true;
                            msg += ", Selected : ";
                            msg += *(m_OtherSymbolsToSell.GetPointerToValue(order.GetValue(i) - m_CurrencyPairsToBuy.Size() - m_CurrencyPairsToSell.Size() - m_OtherSymbolsToBuy.Size()));
                            msg += ":";
                            msg += IInteroperability::DoubleToString(values.GetValue(order.GetValue(i)));
                        }
                    }
                }
            }
			m_Tradable = maxTradableAchived;
            CLogger::LogSpecial(msg);
        }
        
        void LogTradableOfLearnable()
        {
            int learnable = 0;
            int tradable = 0;
            
            for(int i=0;i<m_CurrencyPairsToBuy.Size();i++)
            {
                if((*(m_CurrencyPairsToBuyMulti.GetPointerToValue(i))).Learnable)
                {
                    learnable++;
                    if(IsCurrencyPairToBuyPredictedProfitable(i))
                    {
                        tradable++;
                    }
                }
            }
            for(int i=0;i<m_CurrencyPairsToSell.Size();i++)
            {
                if((*(m_CurrencyPairsToSellMulti.GetPointerToValue(i))).Learnable)
                {
                    learnable++;
                    if(IsCurrencyPairToSellPredictedProfitable(i))
                    {
                        tradable++;
                    }
                }
            }
            for(int i=0;i<m_OtherSymbolsToBuy.Size();i++)
            {
                if((*(m_OtherSymbolsToBuyMulti.GetPointerToValue(i))).Learnable)
                {
                    learnable++;
                    if(IsOtherSymbolToBuyPredictedProfitable(i))
                    {
                        tradable++;
                    }
                }
            }
            for(int i=0;i<m_OtherSymbolsToSell.Size();i++)
            {
                if((*(m_OtherSymbolsToSellMulti.GetPointerToValue(i))).Learnable)
                {
                    learnable++;
                    if(IsOtherSymbolToSellPredictedProfitable(i))
                    {
                        tradable++;
                    }
                }
            }
            CLogger::LogSpecial(IString("Tradable|Learnable : ") + IInteroperability::IntegerToString(tradable) + "|" + IInteroperability::IntegerToString(learnable));
        }
        
		int AmountSymbols(bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return AmountCurrencyPairsToBuy();
				}
				else
				{
					return AmountCurrencyPairsToSell();
				}
			}
			else
			{
				if (Buy)
				{
					return AmountOtherSymbolsToBuy();
				}
				else
				{
					return AmountOtherSymbolsToSell();
				}
			}
		}

        int AmountCurrencyPairsToBuy()
        {
            return m_CurrencyPairsToBuy.Size();
        }
        
        int AmountCurrencyPairsToSell()
        {
            return m_CurrencyPairsToSell.Size();
        }
        
        int AmountOtherSymbolsToBuy()
        {
            return m_OtherSymbolsToBuy.Size();
        }
        
        int AmountOtherSymbolsToSell()
        {
            return m_OtherSymbolsToSell.Size();
        }
        
		IString ReturnSymbol(int nr, bool Symbol, bool Buy)
		{
			if (Symbol)
			{
				if (Buy)
				{
					return ReturnCurrencyPairToBuyNr(nr);
				}
				else
				{
					return ReturnCurrencyPairToSellNr(nr);
				}
			}
			else
			{
				if (Buy)
				{
					return ReturnOtherSymbolToBuyNr(nr);
				}
				else
				{
					return ReturnOtherSymbolToSellNr(nr);
				}
			}
		}

        IString ReturnCurrencyPairToBuyNr(int nr)
        {
            return (*(m_CurrencyPairsToBuy.GetPointerToValue(nr)));
        }
        
        IString ReturnCurrencyPairToSellNr(int nr)
        {
            return (*(m_CurrencyPairsToSell.GetPointerToValue(nr)));;
        }
        
        IString ReturnOtherSymbolToBuyNr(int nr)
        {
            return (*(m_OtherSymbolsToBuy.GetPointerToValue(nr)));;
        }
        
        IString ReturnOtherSymbolToSellNr(int nr)
        {
            return (*(m_OtherSymbolsToSell.GetPointerToValue(nr)));
        }
        
        void LimitCurrencyPairs(IGenericArray<bool> &presentBuy, IGenericArray<bool> &presentSell, IGenericArray<bool> &presentOtherBuy, IGenericArray<bool> &presentOtherSell)
        {
            LimitCurrencyPairs(m_CurrencyPairsToBuy, presentBuy);
            LimitCurrencyPairs(m_CurrencyPairsToSell, presentSell);
            LimitCurrencyPairs(m_OtherSymbolsToBuy, presentOtherBuy);
            LimitCurrencyPairs(m_OtherSymbolsToSell, presentOtherSell);
        }
        
        bool static IsCurrencyPair(IString &symbol)
        {
            for(int i=0;i<CConfig::Currencies.Size();i++)
            {
                if(IsCurrencyPairToBuy((*(CConfig::Currencies.GetPointerToValue(i))), symbol))
                {
                    for(int j=0;j<CConfig::Currencies.Size();j++)
                    {
                        if(IsCurrencyPairToSell((*(CConfig::Currencies.GetPointerToValue(j))), symbol))
                        {
                            return true;
                        }
                    }                    
                }
                else if(IsCurrencyPairToSell((*(CConfig::Currencies.GetPointerToValue(i))), symbol))
                {
                    for(int j=0;j<CConfig::Currencies.Size();j++)
                    {
                        if(IsCurrencyPairToBuy((*(CConfig::Currencies.GetPointerToValue(j))), symbol))
                        {
                            return true;
                        }
                    }                    
                }
            }
            return false;
        }
        
        bool IsLearnable(int symbolNr, bool Symbol, bool SymbolBuy)
        {
            if(Symbol)
            {
                if(SymbolBuy)
                {
                    return (*(m_CurrencyPairsToBuyMulti.GetPointerToValue(symbolNr))).Learnable;
                }
                else
                {
                    return (*(m_CurrencyPairsToSellMulti.GetPointerToValue(symbolNr))).Learnable;
                }
            }
            else
            {
                if(SymbolBuy)
                {
                    return (*(m_OtherSymbolsToBuyMulti.GetPointerToValue(symbolNr))).Learnable;
                }
                else
                {
                    return (*(m_OtherSymbolsToSellMulti.GetPointerToValue(symbolNr))).Learnable;
                }
            }
        }
        
        CLearning* ReturnLearningObject(int symbolNr, bool Symbol, bool SymbolBuy)
        {
            if(Symbol)
            {
                if(SymbolBuy)
                {
                    return &((*(m_CurrencyPairsToBuyMulti.GetPointerToValue(symbolNr))).Learning);
                }
                else
                {
                    return &((*(m_CurrencyPairsToSellMulti.GetPointerToValue(symbolNr))).Learning);
                }
            }
            else
            {
                if(SymbolBuy)
                {
                    return &((*(m_OtherSymbolsToBuyMulti.GetPointerToValue(symbolNr))).Learning);
                }
                else
                {
                    return &((*(m_OtherSymbolsToSellMulti.GetPointerToValue(symbolNr))).Learning);
                }
            }
        }
};
//+------------------------------------------------------------------+
#endif