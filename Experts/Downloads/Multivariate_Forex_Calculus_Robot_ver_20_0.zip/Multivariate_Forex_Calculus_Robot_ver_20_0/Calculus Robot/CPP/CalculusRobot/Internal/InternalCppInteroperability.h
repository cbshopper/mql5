/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_INTERNAL_CPP__INTEROPERABILIT
#define FILE_INTERNAL_CPP_INTEROPERABILIT

#include "InternalCppDateTime.h"
#include "InternalCppString.h"
#include "../ValuesProvider/ValuesProvider.h"
#include <string>
#include <math.h>
#include <time.h>
#include <iostream>

using namespace std;

//+------------------------------------------------------------------+
class IInteroperability
{
private:
	static CValuesProvider m_ValuesProvider;

public:
	void static Activate();

	void static Print(IString &str);

	void static RefreshRates();

	unsigned long static GetLastError();

	int static AccountLeverage();

	static const char* AccountCurrency();

	bool static OrderSelect(int nr, unsigned long ticket);

	unsigned long static HistoryOrderTicket(int nr);

	IDateTime static OrderOpenTime(unsigned long ticket, IDateTime time);

	double static OrderProfit(unsigned long ticket);

	double static OrderOpenPrice(unsigned long ticket);

	double static OrderCurrentPrice(unsigned long ticket);

	double static OrderTakeProfit(unsigned long ticket);

	double static OrderStopLoss(unsigned long ticket);

	static const char* OrderSymbol(unsigned long ticket, IString symbol);

	double static AccountBalance();

	static double GetPriceAtTime(IString symbol, IDateTime date);

	static double GetPriceAtTimeHigh(IString symbol, IDateTime date);

	static double Spread(IString symbol);

	static double BuyPrice(IString symbol);

	static double SellPrice(IString symbol);

	long static OrderSend(IString symbol, bool buy, double lotSize, double price, int slippage, double stopLoss, double takeProfit);

	static int OrdersHistoryTotal();

	static double MathAbs(double val);

	static double MathExp(double val);

	static void EventSetTimer(int secs);

	static void EventKillTimer();

	static bool MathIsValidNumber(double val);

	static int MathCeil(double val);

	static void MathSrand();

	static int MathRand();

	static IString DoubleToString(double val);

	static IString IntegerToString(int val);

	static int SymbolsTotal(bool shown);

	static IString SymbolName(int nr, bool shown);

	static double NormalizeDouble(double price, int digits);

	static int Digits();
};
//+------------------------------------------------------------------+
#endif
