/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_LEARNING
#define FILE_LEARNING

#include "Config.h"
#include "Logger.h"
#include "Fcnnhn/Vectors.h"
#include "Fcnnhn/NeuralNetwork.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/String.h"

//+------------------------------------------------------------------+
class CLearning {
private:
	CNeuralNetwork m_Network;
	int m_outputs;
	bool m_Valid;
	int m_HiddenLayersAmount;
	int m_ActivationFunctionDimension;

	double PercentCorrectlyClassifiedTestVectors(CVectors &vectors, IGenericArray<int> &testVectors, int &positive, int &negative, int &allPos, int &allNeg, int &allPosVec, int &allNegVec)
	{
		double percent = 0.0;
		int amount = 0;
		positive = 0;
		negative = 0;
		allPos = 0;
		allNeg = 0;
		allPosVec = 0;
		allNegVec = 0;

		if (testVectors.Size() > 0)
		{
			for (int i = 0; i < testVectors.Size(); i++)
			{
				CVector vec;
				IGenericArray<double> outputs;

				vec.Init((*(vectors.Vectors.GetPointerToValue(testVectors.GetValue(i)))));
				m_Network.ExitValue(vec.Input, outputs);

				for (int j = 0; j < vec.Output.Size(); j++)
				{
					if (vec.Output.GetValue(j) >= CConfig::ThresholdValue && outputs.GetValue(j) >= CConfig::ThresholdValue)
					{
						amount++;
						positive++;
					}
					else if (vec.Output.GetValue(j) < CConfig::ThresholdValue && outputs.GetValue(j) < CConfig::ThresholdValue)
					{
						amount++;
						negative++;
					}
					if (outputs.GetValue(j) >= CConfig::ThresholdValue)
					{
						allPos++;
					}
					else
					{
						allNeg++;
					}
					if (vec.Output.GetValue(j) >= CConfig::ThresholdValue)
					{
						allPosVec++;
					}
					else
					{
						allNegVec++;
					}
				}
			}
			return amount / (double)testVectors.Size() * (*(vectors.Vectors.GetPointerToValue(0))).Output.Size();
		}
		return 0.0;
	}

public:
	static void InitStatic()
	{
		CRand::Init();
	}

	CLearning()
	{
		m_Valid = false;
	}

	void Init(int in, int out, int hiddenLayersAmount, int activationFunctionDimension)
	{
		IGenericArray<int> amounts;

		m_HiddenLayersAmount = hiddenLayersAmount;
		m_ActivationFunctionDimension = activationFunctionDimension;
		m_outputs = out;
		amounts.Resize(m_HiddenLayersAmount + 2);
		amounts.SetValue(0, in);
		for (int i = 1; i < m_HiddenLayersAmount + 1; i++)
		{
			amounts.SetValue(i, in);
		}
		amounts.SetValue(m_HiddenLayersAmount + 1, out);
		m_Network.Init(amounts, m_ActivationFunctionDimension);
	}

	bool IsPositive(CVector &vec)
	{
		m_Network.ExitValue(vec.Input, vec.Output);

		if (vec.Output.GetValue(0) > CConfig::ThresholdValue)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	void Learn(CVectors &vectors, double percentTest)
	{
		const int EPOCH_STEP = 5;
		IGenericArray<int> inputVectors;
		IGenericArray<int> testVectors;
		IGenericArray<int> learnVectorsOrder;
		int epoch = 0;
		double error;
		double learnReach = 0.0;
		double correctlyTestClassified = 0.0;
		bool testPassed = false;
		bool learnPassed = false;

		if (CConfig::DividedSets)
		{
			CMathNet::DividedSets(inputVectors, testVectors, percentTest, vectors.Vectors.Size());
		}
		else
		{
			CMathNet::RandomSets(inputVectors, testVectors, percentTest, vectors.Vectors.Size());
		}
		learnVectorsOrder.Resize(inputVectors.Size());

		double tmp;
		int _pos = 0, _apos = 0, _Vpos = 0;
		int _neg = 0, _aneg = 0, _Vneg = 0;
		bool cont = true;
		int sameRepeated = 0;

		do
		{
			epoch++;
			error = 0;
			CMathNet::RandomSet(learnVectorsOrder);
			for (int i = 0; i < learnVectorsOrder.Size(); i++)
			{
				tmp = m_Network.Lern((*(vectors.Vectors.GetPointerToValue(inputVectors.GetValue(learnVectorsOrder.GetValue(i))))).Input, (*(vectors.Vectors.GetPointerToValue(inputVectors.GetValue(learnVectorsOrder.GetValue(i))))).Output, CConfig::LearnParameter);
				if (IInteroperability::MathIsValidNumber(tmp))
				{
					error += tmp;
				}
				else
				{
					Init((*(vectors.Vectors.GetPointerToValue(0))).Input.Size(), (*(vectors.Vectors.GetPointerToValue(0))).Output.Size(), m_HiddenLayersAmount, m_ActivationFunctionDimension);
				}
			}
			error /= learnVectorsOrder.Size();
			if (epoch % EPOCH_STEP == 0)
			{
				int pos, neg, TPos, TNeg, VPos, VNeg, apos, aneg, aTPos, aTNeg, aVPos, aVNeg;

				pos = 0; neg = 0; TPos = 0; TNeg = 0; VPos = 0; VNeg = 0; apos = 0; aneg = 0; aTPos = 0; aTNeg = 0; aVPos = 0; aVNeg = 0;

				if (percentTest != 0.0)
				{
					PercentCorrectlyClassifiedTestVectors(vectors, testVectors, TPos, TNeg, aTPos, aTNeg, aVPos, aVNeg);
					if (aTPos == 0 || aTNeg == 0)
					{
						if (aTPos != 0)
						{
							correctlyTestClassified = (double)(TPos) / (double)(aTPos);
							correctlyTestClassified /= 2.0;
						}
						else if (aTNeg != 0)
						{
							correctlyTestClassified = (double)(TNeg) / (double)(aTNeg);
							correctlyTestClassified /= 2.0;
						}
						else
						{
							correctlyTestClassified = -1;
						}
					}
					else
					{
						correctlyTestClassified = (double)(TPos) / (double)(aTPos)+(double)(TNeg) / (double)(aTNeg);
						correctlyTestClassified /= 2.0;
					}
				}

				if (aTPos >= aVPos * CConfig::PercentPassedToAllPassedTest)
				{
					testPassed = true;
				}
				else
				{
					testPassed = false;
				}

				PercentCorrectlyClassifiedTestVectors(vectors, inputVectors, pos, neg, apos, aneg, VPos, VNeg);

				if (pos != _pos || apos != _apos || VPos != _Vpos || neg != _neg || aneg != _aneg || VNeg != _Vneg)
				{
					sameRepeated = 0;
					_pos = pos;
					_apos = apos;
					_Vpos = VPos;
					_neg = neg;
					_aneg = aneg;
					_Vneg = VNeg;
				}
				else
				{
					sameRepeated += EPOCH_STEP;
					if (sameRepeated >= CConfig::MaxEpochSameValues)
					{
						cont = false;
					}
				}

				if (apos == 0 || aneg == 0)
				{
					if (apos != 0)
					{
						learnReach = (double)(pos) / (double)(apos);
						learnReach /= 2.0;
					}
					else if (aneg != 0)
					{
						learnReach = (double)(neg) / (double)(aneg);
						learnReach /= 2.0;
					}
					else
					{
						learnReach = -1;
					}
				}
				else
				{
					learnReach = (double)(pos) / (double)(apos)+(double)(neg) / (double)(aneg);
					learnReach /= 2.0;
				}

				if (apos >= VPos * CConfig::PercentPassedToAllPassedLearn)
				{
					learnPassed = true;
				}
				else
				{
					learnPassed = false;
				}

				if (percentTest != 0.0)
				{
					CLogger::Log(IString("Epoch : ") + IInteroperability::IntegerToString(epoch) + "|" + IInteroperability::IntegerToString(CConfig::MaxEpoch) + ", Error : " + IInteroperability::DoubleToString(error) + ", Learn : " + IInteroperability::DoubleToString(learnReach) + ", Test : " + IInteroperability::DoubleToString(correctlyTestClassified) + ", Pos : " + IInteroperability::IntegerToString(pos) + "|" + IInteroperability::IntegerToString(apos) + "|" + IInteroperability::IntegerToString(VPos) + ", Neg : " + IInteroperability::IntegerToString(neg) + "|" + IInteroperability::IntegerToString(aneg) + "|" + IInteroperability::IntegerToString(VNeg) + ", TPos : " + IInteroperability::IntegerToString(TPos) + "|" + IInteroperability::IntegerToString(aTPos) + "|" + IInteroperability::IntegerToString(aVPos) + ", TNeg : " + IInteroperability::IntegerToString(TNeg) + "|" + IInteroperability::IntegerToString(aTNeg) + "|" + IInteroperability::IntegerToString(aVNeg));
				}
				else
				{
					CLogger::Log(IString("Epoch : ") + IInteroperability::IntegerToString(epoch) + "|" + IInteroperability::IntegerToString(CConfig::MaxEpoch) + ", Error : " + IInteroperability::DoubleToString(error) + ", Learn : " + IInteroperability::DoubleToString(learnReach) + ", Pos : " + IInteroperability::IntegerToString(pos) + "|" + IInteroperability::IntegerToString(apos) + "|" + IInteroperability::IntegerToString(VPos) + ", Neg : " + IInteroperability::IntegerToString(neg) + "|" + IInteroperability::IntegerToString(aneg) + "|" + IInteroperability::IntegerToString(VNeg));
				}
			}
		} while (cont && ((((learnReach < CConfig::LearnPercentReach || !learnPassed) || (correctlyTestClassified < CConfig::TestPercentReachMin || !testPassed)) && percentTest != 0.0) || ((learnReach < CConfig::LearnPercentReach && percentTest == 0.0) || !learnPassed)) && epoch < CConfig::MaxEpoch);

		if ((learnReach >= CConfig::LearnPercentReachMin && percentTest == 0.0 && learnPassed) || (learnReach >= CConfig::LearnPercentReachMin && correctlyTestClassified >= CConfig::TestPercentReachMin && percentTest != 0.0 && learnPassed && testPassed))
		{
			CLogger::LogSpecial(IString("Network is valid."));
			m_Valid = true;
		}
		else
		{
			CLogger::LogSpecial(IString("Network is invalid."));
			m_Valid = false;
		}
	}

	bool IsValid()
	{
		return m_Valid;
	}
};
//+------------------------------------------------------------------+c
#endif
