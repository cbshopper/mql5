/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_ANALYZER
#define FILE_ANALYZER

#include "Logger.h"
#include "../../Interoperability/DateTime.h"
#include "../../Interoperability/Interoperability.h"

//+------------------------------------------------------------------+
class CAnalyzer{
    private:
        double m_MinValue;
        double m_MaxValue;
        bool m_SearchingForMaximum;
        int m_MinDataNr;
        int m_MaxDataNr;
        
        double m_ValueChange;

        IDateTime m_DateOfMin;
        IDateTime m_DateOfMax;        

        int m_MinimasMaximasCount;
        double m_DateDiffrencesSum;
        double m_MinTime;
        double m_MaxTime;
        double m_ValueDiffrencesSum;
        double m_MinValueDiffrence;
        double m_MaxValueDiffrence;
    
        IDateTime m_LastMinimumMaximumDate;
        double m_LastMinimumMaximumValue;
        int m_LastMinimumMaximumDataNr;
    
        void CheckTimes(IDateTime &date)
        {
            double diff = IDateTime::SecondsDiff(m_LastMinimumMaximumDate, date);
            
            m_DateDiffrencesSum += diff;
            if(m_MinTime > diff)
            {
                m_MinTime = diff;
            }
            if(m_MaxTime < diff)
            {
                m_MaxTime = diff;
            }
        }
        
        void CheckValues(double val)
        {
            double diff = IInteroperability::MathAbs(val - m_LastMinimumMaximumValue);
            
            m_ValueDiffrencesSum += diff;
            if(m_MinValueDiffrence > diff)
            {
                m_MinValueDiffrence = diff;
            }
            if(m_MaxValueDiffrence < diff)
            {
                m_MaxValueDiffrence = diff;
            }
        }

    public:
        static const double NO_RESULT;
    
        void SetDefaultMinimumMaximum(double val, double valueChange, IDateTime &date, int dataNr)
        {
            m_MinValue = val;
            m_MaxValue = val;
            m_MinDataNr = dataNr;
            m_MaxDataNr = dataNr;
            m_ValueChange = valueChange;
            m_LastMinimumMaximumDate = date;
            m_LastMinimumMaximumValue = val;
            m_LastMinimumMaximumDataNr = dataNr;
            m_MinTime = 60*60*60;
            m_MaxTime = 0;
            m_MinValueDiffrence = 100;
            m_MaxValueDiffrence = 0;
            m_DateOfMin = date;
            m_DateOfMax = date;
            m_MinimasMaximasCount = 1;
        }
        
        CAnalyzer()
        {
            m_ValueDiffrencesSum = 0;
            m_SearchingForMaximum = true;
            m_MinimasMaximasCount = 1;
            m_DateDiffrencesSum = 0;
        }
        
        void LogCount(IString &symbol)
        {
            if(m_MinimasMaximasCount == 0 || m_MinimasMaximasCount == 1)
            {
                CLogger::HeavyLog(symbol + " No Data.");
            }
            else
            {
                CLogger::HeavyLog(symbol +" Minimas, Maximas Count : " + IInteroperability::IntegerToString(m_MinimasMaximasCount) + " Min Time : " + IDateTime::FromSeconds(m_MinTime) + " Max Time : " + IDateTime::FromSeconds(m_MaxTime) + " Avg Time : " + IDateTime::FromSeconds(m_DateDiffrencesSum / m_MinimasMaximasCount) + " Min Diff : " + IInteroperability::DoubleToString(m_MinValueDiffrence) + " Max Diff : " + IInteroperability::DoubleToString(m_MaxValueDiffrence) + " Avg Diff : " + IInteroperability::DoubleToString(m_ValueDiffrencesSum/(m_MinimasMaximasCount - 1)));
            }
        }

        double AverageTime()
        {
            if(m_MinimasMaximasCount > 0)
            {
                return m_DateDiffrencesSum / m_MinimasMaximasCount;
            }
            else
            {
                return 0;
            }
        }        
        
        double CheckForMinimumMaximum(double val, IDateTime &date, int dataNr)
        {
            double ret = NO_RESULT;
            int retDataNr = -1;
            
            if(m_SearchingForMaximum == false && (val - m_MinValue) > m_ValueChange)
            {
                ret = m_MinValue;
                retDataNr = m_MinDataNr;
                m_SearchingForMaximum = true;
                m_MinValue = val;
                m_MaxValue = val;
                m_MinDataNr = dataNr;
                m_MaxDataNr = dataNr;
                m_MinimasMaximasCount++;
                CheckTimes(m_DateOfMin);
                CheckValues(ret);
                m_LastMinimumMaximumValue = ret;
                m_LastMinimumMaximumDate = m_DateOfMin;
                m_LastMinimumMaximumDataNr = retDataNr;
                m_DateOfMin = date;
                m_DateOfMax = date;
            }
            else if(m_SearchingForMaximum == true && (val - m_MaxValue) < -m_ValueChange)
            {
                ret = m_MaxValue;
                retDataNr = m_MaxDataNr;
                m_SearchingForMaximum = false;
                m_MinValue = val;
                m_MaxValue = val;
                m_MinDataNr = dataNr;
                m_MaxDataNr = dataNr;
                m_MinimasMaximasCount++;
                CheckTimes(m_DateOfMax);
                CheckValues(ret);
                m_LastMinimumMaximumValue = ret;
                m_LastMinimumMaximumDate = m_DateOfMax;
                m_LastMinimumMaximumDataNr = retDataNr;
                m_DateOfMax = date;
                m_DateOfMin = date;
            }
        
            if (m_MinValue > val)
            {
                m_MinValue = val;
                m_DateOfMin = date;
                m_MinDataNr = dataNr;
            }
            if (m_MaxValue < val)
            {
                m_MaxValue = val;
                m_DateOfMax = date;
                m_MaxDataNr = dataNr;
            }            

            return ret;
        }
        
        int ReturnLastMinimumMaximumDataNr()
        {
            return m_LastMinimumMaximumDataNr;
        }
        
        IDateTime ReturnLastMinimumMaximumDate()
        {
            return m_LastMinimumMaximumDate;
        }
        
        int MinimasMaximasAmount()
        {
            return m_MinimasMaximasCount;
        }
};
const double CAnalyzer::NO_RESULT = -1.0;
//+------------------------------------------------------------------+
#endif