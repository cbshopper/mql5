/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_OPEN_TRADES_ON_PROFIT_CLOSER
#define FILE_OPEN_TRADES_ON_PROFIT_CLOSER

#include "../Config.h"
#include "../Logger.h"
#include "../Trading.h"
#include "../../../Interoperability/String.h"
#include "OpenTradesModifierBase.h"

//+------------------------------------------------------------------+
class COpenTradesOnProfitCloser : public COpenTradesModifierBase {
private:

public:
	IString ModifierName()
	{
		return IString("Open Trades On Profit Closer");
	}

	void OnInterval()
	{
		if (IntervalElapsed(CConfig::OpenTradesOnProfitCloserSecondsInterval))
		{
			int tradesAmount = TradesAmount();
			IGenericArray<int> trades;

			trades.Resize(0);
			for (int i = 0; i < tradesAmount; i++)
			{
				if (PercentProfitAchived(i) >= CConfig::OpenTradesOnProfitCloserPercent)
				{
					trades.Resize(trades.Size() + 1);
					trades.SetValue(trades.Size() - 1, i);
				}
			}
			CloseTrades(trades);
		}
	}
};
//+------------------------------------------------------------------+
#endif
