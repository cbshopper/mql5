/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_ACTIVATION_FUNCTION
#define FILE_ACTIVATION_FUNCTION

#include "MinMaxDouble.h"
#include "../../../Interoperability/GenericArray.h"
#include "../../../Interoperability/GenericObjectArray.h"

//+------------------------------------------------------------------+
class CActivationFunction{
    private:
        IGenericObjectArray<CMinMaxDouble> m_dAsympPoints;
        int m_nInputsAmount;
        int m_nPointsAmount;
        
        IGenericArray<double> m_dTmp;
        
        static void CalculateAsympPointsGradients(IGenericArray<double> &dGradients, IGenericArray<double> &dInputs, int nInputsAm, int nPointsAm)
        {
            double dFraction = 1.0 / CMathNet::PowerOfTwo(nInputsAm);

            for (int i = 0; i < nPointsAm; i++)
            {
                dGradients.SetValue(i, dFraction);
                for (int j = 0; j < nInputsAm; j++)
                {
                    if (CMathNet::CheckBit(i, j))
                    {
                        dGradients.SetValue(i, dGradients.GetValue(i) * (1.0 + CMathNet::BipolarSigmoid(dInputs.GetValue(j))));
                    }
                    else
                    {
                        dGradients.SetValue(i, dGradients.GetValue(i) * (1.0 - CMathNet::BipolarSigmoid(dInputs.GetValue(j))));
                    }
                }
            }
        }
        
        static void LowerDimsToDim(int nDimNr, IGenericArray<double> &dInputs, IGenericArray<double> &dPoints, int dInAm)
        {
            int nPairsAmountANDStepSize;
            int nSecondPairsStart = 0;

            nPairsAmountANDStepSize = CMathNet::PowerOfTwo(dInAm - 1);
            for (int nDim = dInAm - 1; nDim >= 0; nDim--)
            {
                if (nDim != nDimNr)
                {
                    for (int nPair = 0; nPair < nPairsAmountANDStepSize; nPair++)
                    {
                        dPoints.SetValue(nPair, CMathNet::FunctionWithAsymptotes(dPoints.GetValue(nPair), dPoints.GetValue(nPair + nPairsAmountANDStepSize), dInputs.GetValue(nDim)));
                    }
                    if (nDim < nDimNr)
                    {
                        for (int nPair = 0; nPair < nPairsAmountANDStepSize; nPair++)
                        {
                            dPoints.SetValue(nSecondPairsStart + nPair, CMathNet::FunctionWithAsymptotes(dPoints.GetValue(nSecondPairsStart + nPair), dPoints.GetValue(nSecondPairsStart + nPair + nPairsAmountANDStepSize), dInputs.GetValue(nDim)));
                        }
                    }
                }
                else
                {
                    nSecondPairsStart = nPairsAmountANDStepSize;
                }
                nPairsAmountANDStepSize /= 2;
            }
            dPoints.SetValue(1, dPoints.GetValue(nSecondPairsStart));
        }

        static void CopyBuffer(IGenericObjectArray<CMinMaxDouble> &dSrc, IGenericArray<double> &dDest, int nAmount)
        {
            for (int i = 0; i < nAmount; i++)
            {
                dDest.SetValue(i, (*(dSrc.GetPointerToValue(i))).Value());
            }
        }
        
    public:
        int Dimension()
        {
            return m_nInputsAmount;
        }
        
        void Init(int dim)
        {
            m_nPointsAmount = CMathNet::PowerOfTwo(dim);

            m_nInputsAmount = dim;
            m_dAsympPoints.Resize(m_nPointsAmount);
            
            for (int i = 0; i < m_nPointsAmount; i++)
            {
                (*(m_dAsympPoints.GetPointerToValue(i))).Init(i, m_nInputsAmount);
            }
            m_dTmp.Resize(m_nPointsAmount);
        }

        double ExitValue(IGenericArray<double> &dInputs)
        {
            CopyBuffer(m_dAsympPoints, m_dTmp, m_nPointsAmount);
            LowerDimsToDim(0, dInputs, m_dTmp, m_nInputsAmount);
            return CMathNet::FunctionWithAsymptotes(m_dTmp.GetValue(0), m_dTmp.GetValue(1), dInputs.GetValue(0));
        }

        double ExitValueFromFormula(IGenericArray<double> &dInputs)
        {
            double dExitValue = 0.0;

            CalculateAsympPointsGradients(m_dTmp, dInputs, m_nInputsAmount, m_nPointsAmount);
            for (int i = 0; i < m_nPointsAmount; i++)
            {
                dExitValue += (*(m_dAsympPoints.GetPointerToValue(i))).Value() * m_dTmp.GetValue(i);
            }
            return dExitValue;
        }
        
        double Lern(IGenericArray<double> &dInputs, double dDesiredOutput, double dLernParam)
        {
            double dExit = ExitValue(dInputs);

            AdaptByGradient(dInputs, 2.0 * (dExit - dDesiredOutput), dLernParam);
            return (dExit - dDesiredOutput) * (dExit - dDesiredOutput);
        }

        void AdaptByGradient(IGenericArray<double> &dInputs, double dGradient, double dLerningParam)
        {
            CalculateAsympPointsGradients(m_dTmp, dInputs, m_nInputsAmount, m_nPointsAmount);
            for (int i = 0; i < m_nPointsAmount; i++)
            {
                (*(m_dAsympPoints.GetPointerToValue(i))).AdaptByGradient(dGradient * m_dTmp.GetValue(i), dLerningParam / CMathNet::PowerOfTwo(m_nInputsAmount));
            }
        }

        void GradientsOnInputs(IGenericArray<double> &dInputs, IGenericArray<double> &dGradients, double dGradient)
        {
            for (int i = 0; i < m_nInputsAmount; i++)
            {
                CopyBuffer(m_dAsympPoints, m_dTmp, m_nPointsAmount);
                LowerDimsToDim(i, dInputs, m_dTmp, m_nInputsAmount);
                dGradients.SetValue(i, dGradient * CMathNet::DerivatFunctionWithAsymptotes(m_dTmp.GetValue(0), m_dTmp.GetValue(1), dInputs.GetValue(i)));
            }
        }
};
//+------------------------------------------------------------------+
#endif