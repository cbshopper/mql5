/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_BOOLS_ARRAY
#define FILE_BOOLS_ARRAY

#include "../../Interoperability/GenericArray.h"

//+------------------------------------------------------------------+
class CBoolArray{
    private:
        void GrowTable()
        {
            m_Bools.Resize(m_Bools.Size() + ARRAY_SIZE_GROWTH);
            for(int i=m_Bools.Size() - ARRAY_SIZE_GROWTH;i<m_Bools.Size();i++)
            {
                m_Bools.SetValue(i, false);
            }
        }

    public:
        const static int ARRAY_SIZE_GROWTH;
        IGenericArray<bool> m_Bools;
                
        CBoolArray()
        {
            m_Bools.Resize(ARRAY_SIZE_GROWTH);
            for(int i=0;i<ARRAY_SIZE_GROWTH;i++)
            {
                m_Bools.SetValue(i, false);
            }
        }
        
        bool GetBool(int nr)
        {
            return m_Bools.GetValue(nr);
        }
        
        void SetBoolTrue(int nr)
        {
            if(nr == m_Bools.Size())
            {
                GrowTable();
            }
            m_Bools.SetValue(nr, true);
        }
        
        void SetBoolFalse(int nr)
        {
            if(nr == m_Bools.Size())
            {
                GrowTable();
            }
            m_Bools.SetValue(nr, false);
        }
        
        int ReturnFirstFalseBoolNr()
        {
            int i;
        
            for(i=0;i<m_Bools.Size();i++)
            {
                if(!m_Bools.GetValue(i))
                {
                    return i;
                }
            }
            if(i == m_Bools.Size())
            {
                GrowTable();
            }
            return m_Bools.Size() - ARRAY_SIZE_GROWTH;
        }
};
const int CBoolArray::ARRAY_SIZE_GROWTH = 5;
//+------------------------------------------------------------------+
#endif