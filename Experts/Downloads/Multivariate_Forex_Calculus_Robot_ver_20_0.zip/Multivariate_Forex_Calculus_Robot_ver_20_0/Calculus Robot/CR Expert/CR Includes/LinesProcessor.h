/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_LINES_PROCESSOR
#define FILE_LINES_PROCESSOR

#include "Line.h"
#include "LineProcessed.h"
#include "../../Interoperability/String.h"

//+------------------------------------------------------------------+
class CLinesProcessor{
    private:
        static const double MIN_VALUE;
        static const double MAX_VALUE;
        
        static void GenerateLine(CPastPoint &point, CLineProcessed &lineProcessed, CValues &values)
        {
            double step = CConfig::NetworkInputsPointsAmount / (double)((CConfig::PastPointsFraction + 1.0) * point.PointsAmount());
            double pos = 0.0;
            IDateTime min;
            IDateTime max;
            CLine line;
            
            lineProcessed.Init(CConfig::NetworkInputsPointsAmount + 1);
            line.Init(values, point);
            min = line.MinTime();
            max = line.MaxTime();
            for(int i=0;i<=CConfig::NetworkInputsPointsAmount;i++)
            {
                lineProcessed.Points.SetValue(i, line.ApproximatedValue(pos, min, max));            
                pos+=step;
            }
        }
        
        static void GenerateLine(IString &symbol, IDateTime &MM, IDateTime &EMM, CLineProcessed &lineProcessed)
        {
            double step = 0;
            double pos = 0.0;
            IDateTime min;
            IDateTime max;
            CLine line;
            
            lineProcessed.Init(CConfig::NetworkInputsPointsAmount + 1);
            line.Init(symbol, MM, EMM);
            step = CConfig::NetworkInputsPointsAmount / (double)((CConfig::PastPointsFraction + 1.0) * line.PointsAmount());
            min = line.MinTime();
            max = line.MaxTime();
            for(int i=0;i<=CConfig::NetworkInputsPointsAmount;i++)
            {
                lineProcessed.Points.SetValue(i, line.ApproximatedValue(pos, min, max));            
                pos+=step;
            }
        }
    
        static void GenerateLines(IGenericObjectArray<CPastPoint> &points, IGenericObjectArray<CLineProcessed> &lines, CValues &values)
        {
            int am = 0;
            int pos = 0;
            
            for(int i=0;i<points.Size();i++)
            {
                if((*(points.GetPointerToValue(i))).IsValid())
                {
                    am++;
                }
            }        
            lines.Resize(am);
            for(int i=0;i<points.Size();i++)
            {
                if((*(points.GetPointerToValue(i))).IsValid())
                {
                    GenerateLine((*(points.GetPointerToValue(i))), (*(lines.GetPointerToValue(pos))), values);
                    pos++;
                }
            }
        }
        
        static void InnerGenerateDifferentialLine(CLineProcessed &line, CLineProcessed &differential)
        {
            differential.Init(line.Points.Size() - 1);
            for(int i=1;i<line.Points.Size() - 1;i++)
            {
                differential.Points.SetValue(i, line.Points.GetValue(i) - line.Points.GetValue(i-1));
            }
        }
        
        static void NormalizeLine(CLineProcessed &line)
        {
            double min = line.Points.GetValue(0);
            double max = line.Points.GetValue(0);
            
            for(int i=0;i<line.Points.Size();i++)
            {
                if(line.Points.GetValue(i) < min)
                {
                    min = line.Points.GetValue(i);
                }
                else if(line.Points.GetValue(i) > max)
                {
                    max = line.Points.GetValue(i);
                }
            }
            for(int i=0;i<line.Points.Size();i++)
            {
                if(max != min)
                {
                    line.Points.SetValue(i, MIN_VALUE + ((line.Points.GetValue(i) - min) / (max - min)) * (MAX_VALUE - MIN_VALUE));
                }
                else
                {
                    line.Points.SetValue(i, MIN_VALUE);
                }
            }
       }
       
    public:
        static void GenerateDifferentialLines(IGenericObjectArray<CPastPoint> &points, IGenericObjectArray<CLineProcessed> &linesDifferential, CValues &values)
        {
            IGenericObjectArray<CLineProcessed> lines;
                        
            GenerateLines(points, lines, values);
            linesDifferential.Resize(lines.Size());
            for(int i=0;i<lines.Size();i++)
            {
                InnerGenerateDifferentialLine((*(lines.GetPointerToValue(i))), (*(linesDifferential.GetPointerToValue(i))));
                NormalizeLine((*(linesDifferential.GetPointerToValue(i))));
            }
        }
        
        static void GenerateDifferentialLine(IString &symbol, IDateTime &MinimumMaximumDate, IDateTime &EstablishingMinimumMaximumDate, CLineProcessed &differential)
        {
            CLineProcessed line;
            
            GenerateLine(symbol, MinimumMaximumDate, EstablishingMinimumMaximumDate, line);
            InnerGenerateDifferentialLine(line, differential);
            NormalizeLine(differential);
        }
};
const double CLinesProcessor::MIN_VALUE = -1.0;
const double CLinesProcessor::MAX_VALUE = 1.0;
//+------------------------------------------------------------------+
#endif