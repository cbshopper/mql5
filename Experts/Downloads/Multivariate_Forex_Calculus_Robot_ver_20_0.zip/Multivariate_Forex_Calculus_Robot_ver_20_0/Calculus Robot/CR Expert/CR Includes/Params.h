/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_PARAMS
#define FILE_PARAMS

#include "Config.h"
#include "Logger.h"
#include "Trading.h"
#include "../../Interoperability/DateTime.h"

//+------------------------------------------------------------------+
class CParams{
    private:
        IDateTime m_LastReverseTradesCheck;
        
    public:
        bool ReverseTrades;
        IDateTime Start;
        int SuccessfullInRow;
        int FailedInRow;
        bool StartedTrading;
        
        int SuccessfullFinds;
        int FailedFinds;
        
        void ZeroFinds()
        {
            SuccessfullFinds = 0;
            FailedFinds = 0;
        }
        
        CParams()
        {
            ReverseTrades = false;
            if(CConfig::SuccededInRow == 0)
            {
                StartedTrading = true;
            }
            else
            {   
                StartedTrading = false;
            }   
            m_LastReverseTradesCheck = IDateTime::TimeCurrent();
            if(!CConfig::ReverseTrades)
            {
                SuccessfullInRow = 0;
                FailedInRow = CConfig::SuccededInRow;
            }
            else
            {
                SuccessfullInRow = CConfig::SuccededInRow;
                FailedInRow = 0;       
            }
            ZeroFinds();
        }
        
        bool IfPerformReverseTradesCheck()
        {
            IDateTime date = IDateTime::TimeCurrent();
            
            if(IDateTime::MinutesDiff(m_LastReverseTradesCheck, date) > CConfig::ReverseTradesPastHoursAmount * 60)
            {
                m_LastReverseTradesCheck = date;
                return true;
            }
            return false;
        }
};
//+------------------------------------------------------------------+
#endif