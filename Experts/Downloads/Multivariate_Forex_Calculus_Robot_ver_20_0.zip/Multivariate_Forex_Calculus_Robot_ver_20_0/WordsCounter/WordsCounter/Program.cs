﻿/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using System;
using System.Collections.Generic;
using System.IO;

namespace WordsCounter
{
    class Program
    {
        private static List<string> ReadFile(string name)
        {
            List<string> list = new List<string>();
            StreamReader reader = new StreamReader(name);
            string line;

            while ((line = reader.ReadLine()) != null)
            {
                list.Add(line);
            }
            reader.Close();
            reader.Dispose();

            return list;
        }

        private static int CountStrings(List<string> list, string search)
        {
            int count = 0;

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Contains(search))
                {
                    count++;
                }
            }

            return count;
        }

        static void Main(string[] args)
        {
            if (args.Length < 3)
            {
                Console.WriteLine("WordsCounter fileName.txt -c|-cps \"term1\" \"term2\" ... ");
                Console.ReadLine();
                return;
            }
            if (args[1] == "-c")
            {
                List<string> list;
                List<int> amounts = new List<int>();
                double sum = 0;

                list = ReadFile(args[0]);

                for (int i = 2; i < args.Length; i++)
                {
                    amounts.Add(CountStrings(list, args[i]));
                    sum += amounts[i - 2];
                }

                for (int i = 2; i < args.Length; i++)
                {
                    Console.WriteLine(args[i] + " : " + amounts[i - 2] + ", Fraction : " + amounts[i - 2] / sum);
                }
            }
            else if (args[1] == "-cps")
            {
                List<string> list;
                List<ProfitSearch> pSearch = new List<ProfitSearch>();

                list = ReadFile(args[0]);
                foreach (string line in list)
                {
                    if (line.Contains("Profit Search Start"))
                    {
                        ProfitSearch ps = new ProfitSearch();

                        ps.Nr = ProfitSearch.Parse(line);
                        pSearch.Add(ps);
                    }
                }
                pSearch.Sort();

                double allEnded = 0;

                foreach (string line in list)
                {
                    if (line.Contains("Profit Search End"))
                    {
                        ProfitSearch ps = new ProfitSearch();
                        int pos;

                        ps.Nr = ProfitSearch.Parse(line);
                        pos = pSearch.BinarySearch(ps);
                        if (pos >= 0)
                        {
                            pSearch[pos].Ended = true;
                            allEnded++;
                        }
                    }
                }

                for (int i = 2; i < args.Length; i++)
                {
                    int found = 0;

                    foreach (string line in list)
                    {
                        if (line.Contains(args[i]))
                        {
                            ProfitSearch ps = new ProfitSearch();
                            int pos;

                            ps.Nr = ProfitSearch.Parse(line);
                            pos = pSearch.BinarySearch(ps);
                            if (pos >= 0 && pSearch[pos].Ended)
                            {
                                found++;
                            }
                        }
                    }
                    Console.WriteLine("{2}, Found : {0}, Percent : {1}.", found, allEnded > 0.0 ? (found / allEnded) : 0.0, args[i]);
                }

                Console.WriteLine("All : {0}.", allEnded);
                Console.ReadLine();
                return;
            }
            else
            {
                Console.WriteLine("WordsCounter fileName.txt -c|-cps \"term1\" \"term2\" ... ");
                Console.ReadLine();
                return;
            }
            Console.ReadLine();
        }
    }
}
