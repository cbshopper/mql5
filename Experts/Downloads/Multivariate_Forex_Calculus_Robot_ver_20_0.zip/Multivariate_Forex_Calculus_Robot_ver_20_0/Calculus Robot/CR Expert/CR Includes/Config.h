/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_CONFIG
#define FILE_CONFIG

#include "../../Interoperability/String.h"

//+------------------------------------------------------------------+
enum OpenTradesModifierType
	{
		NONE,
		ON_PROFIT_CLOSER
	};

class CConfig {
public:
	/*Blocks Robot run if Levarage is to big*/
	const static bool CheckLeverage;
	/*Lot size*/
	const static double MaxVolume;
	/*Maximum Lots amount that can be Traded*/
	const static int MaxAmount;
	/*Stops Robot run if Account Balance to Large*/
	const static bool CheckBalance;
	/*Lot size conversion to real*/
	const static double MinVolume;
	/*Value of slpppage for Ordersend*/
	const static int SlipPage;
	/*Reversing all Trades in last algorithm Step*/
	const static bool ReverseTrades;
	/*Lot size to use for every Trade*/
	const static double LotSize;
	/*Determines how often Robot checks all past trades to determine if reverse trades for future trades*/
	const static int ReverseTradesPastHoursAmount;
	/*If to determine reverse trades based on past trades*/
	const static bool UseReverseTradesPastHours;
	/*If to use Neural Networks in Robot*/
	const static bool UseNeuralNetworks;
	/*If to use trades that were really performed, logic of this is connected to if ReverseTrades was set to true*/
	const static bool UsePerformedTradesForReverseTradesPastHours;

	/*Value of proportional change between established Minimum, Maximum to consider point as next Minimum, Maximum */
	const static double PercentageOfChange;

	/*How often main timer function is called*/
	const static int TimerSecondsAmount;
	/*Historical data interval*/
	const static int MinutesSpan;

	/*Log all log messages*/
	const static bool HeavyLoggingInFile;

	/*How many hours of historical data will be traied to be accessed after every re-initialization*/
	const static int PastHoursCount;
	/*After how many hours elapsed there will be Robot re-initialization*/
	const static int FutureHoursWindow;
	/*How many hours of accessed historical data use to do analysis*/
	const static int PastHoursCountForAnalysis;
	/*If both Neural Networks will be unable to train, after how many hours to re-initialize Robot*/
	const static double FutureHoursInvalidRestart;

	/*Minimum value of TakeProfit Multi*/
	const static double PossibleProfitMultiMin;
	/*Minimum value of StopLoss Multi*/
	const static double StopLossMultiMin;
	/*Maximum value of TakeProfit Multi*/
	const static double PossibleProfitMultiMax;
	/*Maximum value of StopLoss Multi*/
	const static double StopLossMultiMax;
	/*Value of next step of change of both of the Multis*/
	const static double CheckMultiStep;

	/*How many unsuccessfull trades in a row to stop trading*/
	const static int FailedInRow;
	/*How many successfull trades in the row to start trading*/
	const static int SuccededInRow;
	/*How many unsuccessfull trades in a row to stop trading symbol*/
	const static int FailedInRowSingle;
	/*How many successfull trades in the row to start trading symbol*/
	const static int SuccededInRowSingle;
	/*Count each succeeded and failed for every symbol individually*/
	const static bool UseSingleInRow;
	/*Specifies if to bypass logic of determining in there was enought successffullInRow to proceed with trade*/
	const static bool ByPassInRowCheck;

	/*Part of existing Balance to be used in Trading*/
	const static double PercentOfBalanceToTrade;
	/*Lern Neural Networks by examples from percent of Symbols that were determined to be most profitable in analysis of historical data*/
	const static double PercentOfTopCurrenciesToLearn;
	/*How many trades can be run at the same time*/
	const static int SingleTradesAmount;
	/*Which value of Symbol Price determines to use bigger Slip Page value*/
	const static double BiggerSlipPagePriceValue;
	/*Minimum ratio of Gains/Loses to Symbol be considered as taken into account*/
	const static double GainsMinPercentage;
	/*Percent of tradable Symbols from all Symbols that were used during training of the Neural Network*/
	const static double TradableOfLearnedPercent;
	/*Test set is last part of all examples determined during analysis*/
	const static bool DividedSets;
	/*How many determined as passed to all passed in test vectors*/
	const static double PercentPassedToAllPassedTest;
	/*How many determined as passed to all passed in learn vectors*/
	const static double PercentPassedToAllPassedLearn;
	/*How many times try to Learn Neural Network if Network is invalid*/
	const static int NeuralNetworkLearnAttempts;
	/*Successfull/Failed trades in last period, before re-initaialization*/
	const static double LastPeriodSuccessfullPercentMin;
	/*Analysing and Trading only on Currency Pairs;*/
	const static bool UseOnlyCurrencyPairs;
	/*Percent of Narrowing SP and TP*/
	const static double MultiPercent;
    /*Determine minimum amount of Tradable Symbols to Trade in given Period*/
    const static int MinTradableSymbols;
    /*Determines First minimal percent value of profit reached to log that it has happened*/
    const static double MinFirstPercentOfProfitReached;
	/*Determines Second minimal percent value of profit reached to log that it has happened*/
	const static double MinSecondPercentOfProfitReached;
	/*Determines Third minimal percent value of profit reached to log that it has happened*/
	const static double MinThirdPercentOfProfitReached;
	/*Determines Fourth minimal percent value of profit reached to log that it has happened*/
	const static double MinFourthPercentOfProfitReached;

	/*Proceed in executing trades, for testing purposes can be checked only log files if value set to false*/
	const static bool ExecuteTrades;
	/*Determines if to limit Currency Pairs with Account Currency only to Buying or Selling*/
	const static bool ConsiderAccountCurrency;
	/*How often modyfications to open orders are beeing done*/
	const static int IntervalDoModifications;
	/*How often Neural Network for Open Trades Modification is beeing learned*/
	const static int IntervalDoLearning;

	/*Percent of Take Profit change that Stop Loss can have*/
	const static double TakeProfitPercentForStopLoss;
	/*Determines if Normalize Profit*/
	const static bool UseMaxMultiTakeProfitStopLoss;
	/*Percent of Take Profit change that Stop Loss can have to Ignore the Order*/
	const static double TakeProfitPercentForStopLossToIgnore;
	/*Make TakeProfit delta equal StopLoss delata*/
	const static bool MakeStopLossEqualTakeProfit;
	/*Minimal required value of PMS*/
	const static double MinPMSValue;

	/*List of discoverable currencies*/
	static IGenericObjectArray<IString> Currencies;
	/*Lot size if trading Symbols that are not Currency Pairs*/
	const static int LotSizeForNoCurrencies;

	/*Length of Past Points used to train Neural Networks before established Minimum, Maximum*/
	const static double PastPointsFraction;
	/*Amount of Inputs in Neural Networks minus 2(for SL and TP value)*/
	const static int NetworkInputsPointsAmount;
	/*Neural Networks Learn parameter*/
	const static double LearnParameter;
	/*Percent of correctly classified Learn Vectors by Neural Network during Learning to stop Learning*/
	const static double LearnPercentReach;
	/*Percent of correctly classified Learn Vectors by Neural Network during Learning to be considered as valid Neural Network*/
	const static double LearnPercentReachMin;
	/*Amount of hidden layers in Neural Networks*/
	const static int HiddenLayersAmount;
	/*Dimension of Neurons Activation Function*/
	const static int ActivationFunctionDimension;
	/*Amount of hidden layers in Neural Networks used for separate Symbols*/
	const static int HiddenLayersAmountForSymbolNetwork;
	/*Dimension of Neurons Activation Function used for separate Symbols*/
	const static int ActivationFunctionDimensionForSymbolNetwork;
	/*Max amount of epochs of Learning Neural Networks*/
	const static int MaxEpoch;
	/*Max amount of epoch to stop learning when results are constantly the same*/
	const static int MaxEpochSameValues;
	/*Percent of Vectors of all vectors got after analysis that be used as test vectors*/
	const static double TestVectorsPercent;
	/*Output value of Neuron in last layer to vector be considered as passed*/
	const static double ThresholdValue;
	/*Percent of correctly classified Test Vectors by Neural Network during Learning to be considered as valid Neural Network*/
	const static double TestPercentReachMin;

	static void InitCurrencies()
	{
		Currencies.Resize(23);
		(*(Currencies.GetPointerToValue(0))).AssignString("AUD"); (*(Currencies.GetPointerToValue(1))).AssignString("CAD"); (*(Currencies.GetPointerToValue(2))).AssignString("CHF");
		(*(Currencies.GetPointerToValue(3))).AssignString("JPY"); (*(Currencies.GetPointerToValue(4))).AssignString("NZD"); (*(Currencies.GetPointerToValue(5))).AssignString("SGD");
		(*(Currencies.GetPointerToValue(6))).AssignString("USD"); (*(Currencies.GetPointerToValue(7))).AssignString("EUR"); (*(Currencies.GetPointerToValue(8))).AssignString("CZK");
		(*(Currencies.GetPointerToValue(9))).AssignString("DDK"); (*(Currencies.GetPointerToValue(10))).AssignString("GBP"); (*(Currencies.GetPointerToValue(11))).AssignString("HUF");
		(*(Currencies.GetPointerToValue(12))).AssignString("MXN"); (*(Currencies.GetPointerToValue(13))).AssignString("NOK"); (*(Currencies.GetPointerToValue(14))).AssignString("PLN");
		(*(Currencies.GetPointerToValue(15))).AssignString("SEK"); (*(Currencies.GetPointerToValue(16))).AssignString("TRY"); (*(Currencies.GetPointerToValue(17))).AssignString("ZAR");
		(*(Currencies.GetPointerToValue(18))).AssignString("CNH"); (*(Currencies.GetPointerToValue(19))).AssignString("HKD"); (*(Currencies.GetPointerToValue(20))).AssignString("NOK");
		(*(Currencies.GetPointerToValue(21))).AssignString("RUB"); (*(Currencies.GetPointerToValue(22))).AssignString("THB");

	}

	/*Open Trades Modifiers Section Begin*/

	/*Percent of profit achived to Close the Trade*/
	const static double OpenTradesOnProfitCloserPercent;
	/*How often On Profit Closer is beeing run*/
	const static int OpenTradesOnProfitCloserSecondsInterval;
	
	/*Specifies which Trade Modifier to run*/
	const static OpenTradesModifierType OpenTradesModifierChoosen;

	/*Open Trades Modifiers Section End*/
};
const bool CConfig::CheckLeverage = true;
const bool CConfig::CheckBalance = true;

const double CConfig::MaxVolume = 1000.0;
const int CConfig::MaxAmount = 100;
const double CConfig::MinVolume = 0.01;
const double CConfig::LotSize = 0.01;
const int CConfig::SlipPage = 20;

const bool CConfig::UseNeuralNetworks = true;

const int CConfig::TimerSecondsAmount = 1;
const int CConfig::MinutesSpan = 1;

const int CConfig::FutureHoursWindow = 6;
const double CConfig::FutureHoursInvalidRestart = 3.0;

const double CConfig::PossibleProfitMultiMin = 0.0;
const double CConfig::StopLossMultiMin = 0.0;
const double CConfig::PossibleProfitMultiMax = 3.0;
const double CConfig::StopLossMultiMax = 3.0;
const double CConfig::CheckMultiStep = 0.03;

const int CConfig::FailedInRow = 0;
const int CConfig::SuccededInRow = 0;
const int CConfig::FailedInRowSingle = 0;
const int CConfig::SuccededInRowSingle = 0;
const bool CConfig::UseSingleInRow = false;
const bool CConfig::ByPassInRowCheck = true;

const bool CConfig::ReverseTrades = false;
const int CConfig::ReverseTradesPastHoursAmount = 7 * 24;
const bool CConfig::UseReverseTradesPastHours = false;
const bool CConfig::UsePerformedTradesForReverseTradesPastHours = false;

const double CConfig::PercentOfBalanceToTrade = 1.0;
const double CConfig::PercentOfTopCurrenciesToLearn = 1.0;
const int CConfig::SingleTradesAmount = 10;
const double CConfig::BiggerSlipPagePriceValue = 100.0;
const bool CConfig::DividedSets = true;
const int CConfig::NeuralNetworkLearnAttempts = 3;
const bool CConfig::UseOnlyCurrencyPairs = true;
IGenericObjectArray<IString> CConfig::Currencies;

const bool CConfig::HeavyLoggingInFile = true;

const bool CConfig::ExecuteTrades = true;
const bool CConfig::ConsiderAccountCurrency = false;
const int CConfig::IntervalDoModifications = 5;
const int CConfig::IntervalDoLearning = 10 * 60;

const int CConfig::LotSizeForNoCurrencies = 5;

const double CConfig::PastPointsFraction = 2.0;
const int CConfig::NetworkInputsPointsAmount = 30;
const double CConfig::LearnParameter = 0.001;
const int CConfig::HiddenLayersAmount = 4;
const int CConfig::ActivationFunctionDimension = 3;
const int CConfig::HiddenLayersAmountForSymbolNetwork = 2;
const int CConfig::ActivationFunctionDimensionForSymbolNetwork = 3;
const int CConfig::MaxEpoch = 1000;
const int CConfig::MaxEpochSameValues = 100;
const double CConfig::ThresholdValue = 0.2;
const bool CConfig::UseMaxMultiTakeProfitStopLoss = true;
const double CConfig::TakeProfitPercentForStopLossToIgnore = 1.15;
const double CConfig::MultiPercent = 0.75;
const bool CConfig::MakeStopLossEqualTakeProfit = true;
const double CConfig::MinPMSValue = 0.001;
const int CConfig::MinTradableSymbols = 3;
const double CConfig::MinFirstPercentOfProfitReached = 0.2;
const double CConfig::MinSecondPercentOfProfitReached = 0.4;
const double CConfig::MinThirdPercentOfProfitReached = 0.6;
const double CConfig::MinFourthPercentOfProfitReached = 0.8;

const double CConfig::GainsMinPercentage = 5.0;
const double CConfig::TradableOfLearnedPercent = 1.0;
const double CConfig::TestVectorsPercent = 0.2;
const double CConfig::TestPercentReachMin = 0.4;
const double CConfig::LearnPercentReach = 0.75;
const double CConfig::LearnPercentReachMin = 0.4;
const double CConfig::PercentPassedToAllPassedTest = 0.1;
const double CConfig::PercentPassedToAllPassedLearn = 0.25;

const double CConfig::TakeProfitPercentForStopLoss = 1.0; //For 1.0 StopLoss is max 100% of TakeProfit, 
														  //that means that statistically to make overall profit there is need for at least 50% of Trades to be Successfull.
const double CConfig::LastPeriodSuccessfullPercentMin = 0.5;

const double CConfig::PercentageOfChange = 0.003;
const int CConfig::PastHoursCount = 7 * 24;
const int CConfig::PastHoursCountForAnalysis = 5 * 24;


/*Open Trades Modifiers Section Begin*/

const double CConfig::OpenTradesOnProfitCloserPercent = 0.5;
const int CConfig::OpenTradesOnProfitCloserSecondsInterval = 5;

const OpenTradesModifierType CConfig::OpenTradesModifierChoosen = OpenTradesModifierType::NONE;

/*Open Trades Modifiers Section End*/
//+------------------------------------------------------------------+
#endif
