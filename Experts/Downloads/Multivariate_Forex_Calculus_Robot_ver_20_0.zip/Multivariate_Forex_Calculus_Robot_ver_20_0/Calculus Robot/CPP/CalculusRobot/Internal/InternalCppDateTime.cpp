/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#include "InternalCppDateTime.h"


IDateTime::IDateTime()
{

}

bool IDateTime::operator<(const IDateTime &other)
{
	return m_Time < other.m_Time;
}

bool IDateTime::operator>(const IDateTime &other)
{
	return m_Time > other.m_Time;
}

IDateTime::IDateTime(const IDateTime &other)
{
	m_Time = other.m_Time;
}

IDateTime IDateTime::TimeCurrent()
{
	IDateTime t;

	t.m_Time = time(NULL);

	return t;
}

IString IDateTime::GetDay(IDateTime &time)
{
	return IString("Day");
}

IDateTime IDateTime::AddMinute(IDateTime &time)
{
	IDateTime date;

	date.m_Time = time.m_Time + 60 * 1;

	return date;
}

IDateTime IDateTime::AddMinutes(IDateTime &time, int minutes)
{
	IDateTime date;

	date.m_Time = date.m_Time + 60 * minutes;

	return date;
}

IDateTime IDateTime::AddSeconds(IDateTime &time, int seconds)
{
	IDateTime date;

	date.m_Time = time.m_Time += seconds;

	return date;
}

int IDateTime::MinutesDiff(IDateTime &before, IDateTime &after)
{
	return (int)(difftime(after.m_Time, before.m_Time) / 60.0);
}

IDateTime IDateTime::MinusHours(IDateTime &time, int hoursAm)
{
	IDateTime date;

	date.m_Time = time.m_Time - hoursAm * 60 * 60;

	return date;
}

double IDateTime::SecondsDiff(IDateTime &before, IDateTime &after)
{
	return (int)(difftime(after.m_Time, before.m_Time));
}

IString IDateTime::FromSeconds(double seconds)
{
	int sec = (int)(seconds);
	int min = (int)(seconds / 60.0);
	int hour = (int)(seconds / (60.0*60.0));

	sec -= min * 60;
	min -= hour * 60;

	return IString(hour) + ":" + IString(min) + ":" + IString(sec);
}

IString IDateTime::TimeCurrentAsString()
{
	IDateTime time(TimeCurrent());
	char buffer[100];

	ctime_s(buffer, 100, &(time.m_Time));

	IString str(buffer);

	return str;
}