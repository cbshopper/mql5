/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MATHNET
#define FILE_MATHNET

#include "Rand.h"
#include "../../../Interoperability/GenericArray.h"
#include "../../../Interoperability/Interoperability.h"

//+------------------------------------------------------------------+
class CMathNet{
    private:
        static const double dB;
   
        static int CountTrues(IGenericArray<bool> &bools)
        {
            int am = 0;
            
            for(int i=0;i<bools.Size();i++)
            {
                if(bools.GetValue(i) == true)
                {
                    am++;
                }
            }
            return am;
        }
   
        static void SetFalse(IGenericArray<bool> &bools, int nr)
        {
            int am = -1;
            
            for(int i=0;i<bools.Size();i++)
            {
                if(bools.GetValue(i) == true)
                {
                    am++;                    
                    if(am == nr)
                    {
                        bools.SetValue(i, false);
                        return;
                    }
                }
            }
        }
        
        static int ReturnPosOfNr(IGenericArray<bool> &bools, int nr)
        {
            int am = -1;

            for(int i=0;i<bools.Size();i++)
            {
                if(bools.GetValue(i) == true)
                {
                    am++;
                    if(am == nr)
                    {
                        return i;
                    }
                }
            }
            return -1;
        }
        
        static bool BelongsTo(IGenericArray<int> &except, int value)
        {
            for(int i=0;i<except.Size();i++)
            {
                if(except.GetValue(i) == value)
                {
                    return true;
                }
            }
            return false;
        }
        
        static int GetBiggestValueNrExcept(IGenericArray<double> &values, IGenericArray<int> &except)
        {
            int max;
            int i = 0;
            
            while(BelongsTo(except, i))
            {
                i++;
            }
            
            max = i;
            i++;
            for(;i<values.Size();i++)
            {
                 if(values.GetValue(i) > values.GetValue(max) && !BelongsTo(except, i))
                 {
                     max = i;
                 }
            }
            return max;
        }
        
    public:
        static void RandomSet(IGenericArray<int> &vals)
        {
            IGenericArray<bool> tmpBool;
            
            tmpBool.Resize(vals.Size());
            for(int i=0;i<vals.Size();i++)
            {
                tmpBool.SetValue(i, true);
            }
            for(int i=0;i<vals.Size();i++)
            {
                int am = CountTrues(tmpBool);
                
                if(am > 0)
                {
                    int nr = RandomInt(0, am-1);
                    
                    vals.SetValue(ReturnPosOfNr(tmpBool, nr), i);
                    SetFalse(tmpBool, nr);
                }
            }
        }
        
        static void RandomSets(IGenericArray<int> &first, IGenericArray<int> &second, double percent, int wholeSize)
        {
            int secondSize = (int)(percent * wholeSize);
            IGenericArray<int> tmps;
            
            tmps.Resize(wholeSize);
            RandomSet(tmps);
            first.Resize(wholeSize - secondSize);
            second.Resize(secondSize);
            for(int i=0;i<wholeSize - secondSize;i++)
            {
                first.SetValue(i, tmps.GetValue(i));            
            }
            for(int i=wholeSize-secondSize;i<wholeSize;i++)
            {
                second.SetValue(i-(wholeSize - secondSize), tmps.GetValue(i));
            }
        }
        
        static void DividedSets(IGenericArray<int> &first, IGenericArray<int> &second, double percent, int wholeSize)
        {
            int secondSize = (int)(percent * wholeSize);
            
            first.Resize(wholeSize - secondSize);
            second.Resize(secondSize);
            for(int i=0;i<wholeSize - secondSize;i++)
            {
                first.SetValue(i, i);
            }
            for(int i=wholeSize-secondSize;i<wholeSize;i++)
            {
                second.SetValue(i-(wholeSize - secondSize), i);
            }
        }
    
        static double Random(double min, double max)
        {
            return CRand::DoubleFromRange(min, max);
        }
    
        static int RandomInt(int min, int max)
        {
            int res = max + 1;
            
            while(res == max+1)
            {
                res = (int)(Random(min, max + 1.0));
            }
            return res;
        }
    
        static int CheckBit(int nValue, int nBitNr)
        {
            if ((nValue & (1 << nBitNr)) != 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        static int AmountOfOnes(int nr, int ib)
        {
            int sum = 0;

            for (int i = 0; i < ib; i++)
            {
                sum += CheckBit(nr, i);
            }
            return sum;
        }

        static int PowerOfTwo(int nPower)
        {
	        int nResult = 1;

            nResult <<= nPower;
	        return nResult;
        }
        
        static double BipolarSigmoid(double dX)
        {
            if(!IInteroperability::MathIsValidNumber(dX))
            {
                dX = 0.0;
            }        
            return 2.0 / (1.0 + IInteroperability::MathExp(-dB * dX)) - 1.0;
        }
        
        static double FunctionWithAsymptotes(double dBottom, double dTop, double dX)
        {
            if(!IInteroperability::MathIsValidNumber(dX))
            {
                dX = 0.0;
            }        
            return ((dTop - dBottom) / 2.0) * BipolarSigmoid(dX) + ((dTop + dBottom) / 2.0);
        }

        static double DerivatBipolarSigmoid(double dX)
        {
            if(!IInteroperability::MathIsValidNumber(dX))
            {
                dX=0.0;
            }
            
            double tmpFunVal = IInteroperability::MathExp(-dB * dX);
            return (2 * dB * tmpFunVal) / ((1 + tmpFunVal) * (1 + tmpFunVal));
        }

        static double DerivatFunctionWithAsymptotes(double dBottom, double dTop, double dX)
        {
            return ((dTop - dBottom) / 2.0) * DerivatBipolarSigmoid(dX);
        }
        
        static double Normalize(double val, double max)
        {
            return val / max;
        }
        
        static double DeNormalize(double val, double max)
        {
            return val * max;
        }
        
        static void GetBiggestValuesNrs(IGenericArray<double> &values, IGenericArray<int> &found)
        {
            IGenericArray<int> except;
        
            for(int i=0;i<found.Size();i++)
            {
                int max = GetBiggestValueNrExcept(values, except);
                
                except.Resize(i+1);
                except.SetValue(i, max);
            }
            for(int i=0;i<found.Size();i++)
            {
                found.SetValue(i, except.GetValue(i));
            }
        }
        
        static int CalculateHiddenSize(int inputAmount, int outputAmount, int hiddenLayersAmount, int LayerNumber)
        {
            double x1 = 1.0;
            double x2 = (double)(hiddenLayersAmount + 2);
            double y1 = (double)inputAmount;
            double y2 = (double)outputAmount;

            return (int)IInteroperability::MathCeil(((y1 - y2) / (x1 - x2)) * LayerNumber + (y2 * x1 - y1 * x2) / (x1 - x2));
        }
};
const double CMathNet::dB = 5.625;
//+------------------------------------------------------------------+
#endif