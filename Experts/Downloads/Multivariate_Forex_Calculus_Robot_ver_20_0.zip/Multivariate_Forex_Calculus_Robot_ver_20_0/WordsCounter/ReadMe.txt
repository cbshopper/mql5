To Words Counter, there is need to use Visual Studio 2017 Community Edition.

Words Counter counts ocurrences on frazes present in logs (the ones special....txt) from Calculus Robot.

To use it compile WordsCounter, put WordsCounter.exe, special log with name changed to log.txt and contents of Scripts directory to one directory and run one of the scripts.
