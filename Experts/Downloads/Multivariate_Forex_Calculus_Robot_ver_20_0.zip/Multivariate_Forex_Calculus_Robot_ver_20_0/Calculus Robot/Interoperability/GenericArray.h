/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_GENERIC_ARRAY
#define FILE_GENERIC_ARRAY

#ifndef CPP
//+------------------------------------------------------------------+
template <typename T>
class IGenericArray{
	 private:
		 T m_Array[];
		 
	 public:
		 void Resize(int am)
		 {
			 int curSize = ArraySize(m_Array);
			 
			 ArrayResize(m_Array, am);
			 if(typename(T) == "int")
			 {
				 for(int i=curSize;i<am;i++)
				 {
					 m_Array[i] = 0;
				 }
			 }
			 else if(typename(T) == "double")
			 {
				 for(int i=curSize;i<am;i++)
				 {
					 m_Array[i] = 0.0;
				 }
			 }
			 else if(typename(T) == "bool")
			 {
				 for(int i=curSize;i<am;i++)
				 {
					 m_Array[i] = false;
				 }
			 }
		 }         
		 
		 void SetValue(int nr, const T val)
		 {
			 m_Array[nr] = val;
		 }
		 
		 const T GetValue(int nr)
		 {
			 return m_Array[nr];
		 }
		 
		 const int Size()
		 {
			 return ArraySize(m_Array);
		 }

		 void Sort()
		 {
			 ArraySort(m_Array);
		 }
};
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppGenericArray.h"

#endif
#endif