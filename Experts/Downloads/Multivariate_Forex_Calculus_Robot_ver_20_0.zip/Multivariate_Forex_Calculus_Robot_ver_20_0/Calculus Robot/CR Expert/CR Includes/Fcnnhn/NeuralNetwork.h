/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_NEURAL_NETWORK
#define FILE_NEURAL_NETWORK

#include "NetNeuron.h"

//+------------------------------------------------------------------+
class CArrayDouble{
    public:
        IGenericArray<double> Values;
        
        void Init(int am)
        {
            Values.Resize(am);
        }
};
//+------------------------------------------------------------------+
class CLayer{
    public:
        IGenericObjectArray<CNetNeuron> Neurons;
        
        void Init(int amountInLayer, int inputsAmount, int activationFunctionDim)
        {
            Neurons.Resize(amountInLayer);
            for(int i=0;i<amountInLayer;i++)
            {
                (*(Neurons.GetPointerToValue(i))).Init(inputsAmount, activationFunctionDim);
            }
        }
        
        int Amount()
        {
            return Neurons.Size();
        }
};
//+------------------------------------------------------------------+
class CNeuralNetwork{
    private:
        IGenericObjectArray<CLayer> m_Layers;
    
        void CreateBuffer(IGenericArray<double> &src, IGenericArray<double> &dst)
        {
            dst.Resize(src.Size());

            for (int i = 0; i < src.Size(); i++)
            {
                dst.SetValue(i, src.GetValue(i));
            }
        }

        void AddToBuffer(IGenericArray<double> &Buffer, IGenericArray<double> &Add)
        {
            for (int i = 0; i < Buffer.Size(); i++)
            {
                Buffer.SetValue(i, Buffer.GetValue(i) + Add.GetValue(i));
            }
        }
        
        void AdaptByGradient(IGenericObjectArray<CArrayDouble> &dInputs, IGenericArray<double> &dGradients, double dLernParam)
        {
            IGenericArray<double> gradients;
            IGenericArray<double> neuronGradients;

            gradients.Resize((*(dInputs.GetPointerToValue(dInputs.Size() - 2))).Values.Size());
            neuronGradients.Resize((*(dInputs.GetPointerToValue(dInputs.Size() - 2))).Values.Size());
            for (int i = 0; i < (*(m_Layers.GetPointerToValue(m_Layers.Size() - 1))).Neurons.Size(); i++)
            {
                (*((*(m_Layers.GetPointerToValue(m_Layers.Size() - 1))).Neurons.GetPointerToValue(i))).GradientsOnInputs((*(dInputs.GetPointerToValue(dInputs.Size() - 2))).Values, neuronGradients, dGradients.GetValue(i));
                AddToBuffer(gradients, neuronGradients);
                (*((*(m_Layers.GetPointerToValue(m_Layers.Size() - 1))).Neurons.GetPointerToValue(i))).AdaptByGradient((*(dInputs.GetPointerToValue(dInputs.Size() - 2))).Values, dGradients.GetValue(i), dLernParam);
            }

            dGradients.Resize(gradients.Size());
            CreateBuffer(dGradients, gradients);
            for (int i = m_Layers.Size() - 2; i > 0; i--)
            {
                IGenericArray<double> grads; 
                IGenericArray<double> neuronGrads;

                grads.Resize(((*(m_Layers.GetPointerToValue(i - 1))).Neurons.Size()));
                neuronGrads.Resize(((*(m_Layers.GetPointerToValue(i - 1))).Neurons.Size()));
                for (int j = 0; j < ((*(m_Layers.GetPointerToValue(i))).Neurons.Size()); j++)
                {
                    (*((*(m_Layers.GetPointerToValue(i)))).Neurons.GetPointerToValue(j)).GradientsOnInputs((*(dInputs.GetPointerToValue(i))).Values, grads, dGradients.GetValue(j));
                    AddToBuffer(grads, neuronGrads);
                    (*((*(m_Layers.GetPointerToValue(i)))).Neurons.GetPointerToValue(j)).AdaptByGradient((*(dInputs.GetPointerToValue(i))).Values, dGradients.GetValue(j), dLernParam);
                }
                dGradients.Resize(grads.Size());
                CreateBuffer(grads, dGradients);
            }

            if (m_Layers.Size() > 1)
            {
                for (int j = 0; j < (*(m_Layers.GetPointerToValue(0))).Neurons.Size(); j++)
                {
                    (*(*(m_Layers.GetPointerToValue(0))).Neurons.GetPointerToValue(j)).AdaptByGradient((*(dInputs.GetPointerToValue(0))).Values, dGradients.GetValue(j), dLernParam);
                }
            }
        }

    public:
        void Init(IGenericArray<int> &amountInLayers, int activationFunctionDimension)
        {
            m_Layers.Resize(amountInLayers.Size() - 1);
            for (int i = 1; i < amountInLayers.Size(); i++)
            {
                (*(m_Layers.GetPointerToValue(i-1))).Init(amountInLayers.GetValue(i), amountInLayers.GetValue(i-1), activationFunctionDimension);
            }
        }
        
        void ExitValue(IGenericArray<double> &inputs, IGenericArray<double> &outputs)
        {
            for (int i = 0; i < m_Layers.Size(); i++)
            {
                outputs.Resize((*(m_Layers.GetPointerToValue(i))).Amount());

                for (int j = 0; j < (*(m_Layers.GetPointerToValue(i))).Amount(); j++)
                {
                    outputs.SetValue(j, (*(*(m_Layers.GetPointerToValue(i))).Neurons.GetPointerToValue(j)).ExitValue(inputs));
                }
                inputs.Resize(outputs.Size());
                CreateBuffer(outputs, inputs);
            }
        }
        
        double Lern(IGenericArray<double> &dInputs, IGenericArray<double> &dDesiredOutputs, double dLernParam)
        {
            IGenericObjectArray<CArrayDouble> dOutputs;
            
            dOutputs.Resize(m_Layers.Size() + 1);
            
            (*(dOutputs.GetPointerToValue(0))).Init(dInputs.Size());
            CreateBuffer(dInputs, (*(dOutputs.GetPointerToValue(0))).Values);
            for (int i = 0; i < m_Layers.Size(); i++)
            {
                IGenericArray<double> layerOutputs;
                
                layerOutputs.Resize((*(m_Layers.GetPointerToValue(i))).Neurons.Size());

                for (int j = 0; j < (*(m_Layers.GetPointerToValue(i))).Neurons.Size(); j++)
                {
                    layerOutputs.SetValue(j, (*(*(m_Layers.GetPointerToValue(i))).Neurons.GetPointerToValue(j)).ExitValue((*(dOutputs.GetPointerToValue(i))).Values));
                }
                (*(dOutputs.GetPointerToValue(i+1))).Values.Resize(layerOutputs.Size());
                CreateBuffer(layerOutputs, (*(dOutputs.GetPointerToValue(i+1))).Values);
            }
            
            double dError = 0.0;
            IGenericArray<double> dGradients;
            
            dGradients.Resize((*(dOutputs.GetPointerToValue(dOutputs.Size() - 1))).Values.Size());
            
            for (int i = 0; i < dDesiredOutputs.Size(); i++)
            {
                double dY = (*(dOutputs.GetPointerToValue(dOutputs.Size() - 1))).Values.GetValue(i);
                dGradients.SetValue(i, 2.0 * (dY - dDesiredOutputs.GetValue(i)));
                dError += (dDesiredOutputs.GetValue(i) - dY) * (dDesiredOutputs.GetValue(i) - dY);
            }

            AdaptByGradient(dOutputs, dGradients, dLernParam);
            return dError;
        }     
};
//+------------------------------------------------------------------+
#endif