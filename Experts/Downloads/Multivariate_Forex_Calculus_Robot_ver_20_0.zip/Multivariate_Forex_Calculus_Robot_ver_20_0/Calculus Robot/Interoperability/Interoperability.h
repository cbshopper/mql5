/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_INTEROPERABILIT
#define FILE_INTEROPERABILIT

#ifndef CPP
#define MQL4

#include "String.h"
#include "DateTime.h"

//+------------------------------------------------------------------+
class IInteroperability
{
    public:
		void static Activate()
		{
#ifdef MQL4  
			::RefreshRates();
#endif             
#ifdef MQL5      
            
#endif
		}

        void static Print(IString &str)
        {
            ::Print(str.GetPlatformString());
        }        
    
        void static RefreshRates()
        {
#ifdef MQL4           
            ::RefreshRates();
#endif             
#ifdef MQL5      
            
#endif
        }  
        
        int static AccountLeverage()
        {
#ifdef MQL4           
           return ::AccountLeverage();
#endif             
#ifdef MQL5      
           return ::AccountInfoInteger(ACCOUNT_LEVERAGE);
#endif
        }  
        
		static unsigned long GetLastError()
		{
			return ::GetLastError();
		}

        static IString AccountCurrency()
        {
#ifdef MQL4           
           return IString(::AccountCurrency());
#endif             
#ifdef MQL5      
           return IString(::AccountInfoString(ACCOUNT_CURRENCY));
#endif
        }
        
        bool static OrderSelect(int nr, ulong ticket)
        {
#ifdef MQL4           
           return ::OrderSelect(nr,SELECT_BY_POS,MODE_HISTORY);
#endif             
#ifdef MQL5      
           return ::HistoryOrderSelect(ticket);
#endif
        }

		double static OrderTakeProfit(ulong ticket)
		{
#ifdef MQL4           
			return ::OrderTakeProfit();
#endif             
#ifdef MQL5      
			return ::HistoryOrderGetDouble(ticket, ORDER_TP);
#endif
		}

		double static OrderStopLoss(ulong ticket)
		{
#ifdef MQL4           
			return ::OrderStopLoss();
#endif             
#ifdef MQL5      
			return ::HistoryOrderGetDouble(ticket, ORDER_SL);
#endif
		}

        unsigned long static HistoryOrderTicket(int nr)
        {
#ifdef MQL4           
           return 0;
#endif             
#ifdef MQL5      
           return ::HistoryOrderGetTicket(nr);
#endif
        }
        
        void static OrderOpenTime(ulong ticket, IDateTime &res)
        {
#ifdef MQL4           
           res = IDateTime(::OrderOpenTime());
#endif             
#ifdef MQL5      
           res = IDateTime(::HistoryOrderGetInteger(ticket, ORDER_TIME_DONE));
#endif
        }
        
        double static OrderOpenPrice(ulong ticket)
        {
#ifdef MQL4           
           return ::OrderOpenPrice();
#endif             
#ifdef MQL5      
           return ::HistoryOrderGetDouble(ticket, ORDER_PRICE_OPEN);
#endif
        }

        double static OrderProfit(ulong ticket)
        {
#ifdef MQL4           
           return ::OrderProfit();
#endif             
#ifdef MQL5      
           return ::HistoryDealGetDouble(ticket, DEAL_PROFIT);
#endif
        }

        double static OrderCurrentPrice(ulong ticket)
        {
            IString symbol;
            
            OrderSymbol(ticket, symbol);
#ifdef MQL4           
            return BuyPrice(symbol);           
#endif             
#ifdef MQL5      
            return BuyPrice(symbol);
#endif
        }

        void static OrderSymbol(ulong ticket, IString &res)
        {
#ifdef MQL4           
           res = IString(::OrderSymbol());
#endif             
#ifdef MQL5      
           res = IString(::HistoryOrderGetString(ticket, ORDER_SYMBOL));
#endif
        }

        double static AccountBalance()
        {
#ifdef MQL4           
           return ::AccountBalance();
#endif             
#ifdef MQL5      
           return ::AccountInfoDouble(ACCOUNT_BALANCE);
#endif
        }  
        
        static double GetPriceAtTime(IString &symbol, IDateTime &date)
        { 
#ifdef MQL4 
            int iWhenM1 = iBarShift(symbol.GetPlatformString(), PERIOD_M1, date.GetPlatformTime());
            return iLow(symbol.GetPlatformString(), PERIOD_M1, iWhenM1);
#endif             
#ifdef MQL5      
            int iWhenM1 = iBarShift(symbol.GetPlatformString(), PERIOD_M1, date.GetPlatformTime());
            return iLow(symbol.GetPlatformString(), PERIOD_M1, iWhenM1);
#endif
        }
        
        static double GetPriceAtTimeHigh(IString &symbol, IDateTime &date)
        { 
#ifdef MQL4 
            int iWhenM1 = iBarShift(symbol.GetPlatformString(), PERIOD_M1, date.GetPlatformTime());
            return iHigh(symbol.GetPlatformString(), PERIOD_M1, iWhenM1);
#endif             
#ifdef MQL5      
            int iWhenM1 = iBarShift(symbol.GetPlatformString(), PERIOD_M1, date.GetPlatformTime());
            return iHigh(symbol.GetPlatformString(), PERIOD_M1, iWhenM1);
#endif
        }
        
        static double Spread(IString &symbol)
        {
#ifdef MQL4 
            return MarketInfo(symbol.GetPlatformString(), MODE_ASK) - MarketInfo(symbol.GetPlatformString(), MODE_BID);
#endif             
#ifdef MQL5      
            return SymbolInfoDouble(symbol.GetPlatformString(), SYMBOL_ASK) - SymbolInfoDouble(symbol.GetPlatformString(), SYMBOL_BID);
#endif
        }
        
        static double BuyPrice(IString &symbol)
        {
#ifdef MQL4 
            return MarketInfo(symbol.GetPlatformString(), MODE_ASK);
#endif             
#ifdef MQL5      
            return ::SymbolInfoDouble(symbol.GetPlatformString(),SYMBOL_ASK);
#endif
        }
        
        static double SellPrice(IString &symbol)
        {
#ifdef MQL4 
            return MarketInfo(symbol.GetPlatformString(), MODE_BID);
#endif             
#ifdef MQL5      
            return ::SymbolInfoDouble(symbol.GetPlatformString(), SYMBOL_BID);
#endif
        }
        
        long static OrderSend(IString &symbol, bool buy, double lotSize, double price, int slippage, double stopLoss, double takeProfit)
        {
#ifdef MQL4 
            return ::OrderSend(symbol.GetPlatformString(), buy ? OP_BUY : OP_SELL, lotSize, price, slippage, stopLoss, takeProfit);
#endif             
#ifdef MQL5      
            MqlTradeResult result;
            MqlTradeRequest request;
            
            ZeroMemory(request);
            ZeroMemory(result);
            request.symbol = symbol.GetPlatformString();
            request.action = TRADE_ACTION_DEAL;
            request.type_filling = ORDER_FILLING_FOK;
            request.type = buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
            request.volume = lotSize;
            request.price = price;
            request.sl = stopLoss;
            request.tp = takeProfit;
            request.deviation = slippage;
            
            if(::OrderSend(request, result))
            {
                return result.request_id;
            }
            else
            {
                return -1;
            }        
#endif
        }  

        static int OrdersHistoryTotal()
        {
#ifdef MQL4 
            return ::OrdersHistoryTotal();
#endif             
#ifdef MQL5      
            return ::HistoryOrdersTotal();
#endif
        }

      static int SymbolsTotal(bool shown)
      {
          return ::SymbolsTotal(shown);
      }

      static IString SymbolName(int nr, bool shown)
      {
          IString symbol(::SymbolName(nr, shown));
          
          return symbol;
      }

		static double MathAbs(double val)
		{
			return ::MathAbs(val);
		}

		static double MathExp(double val)
		{
			return ::MathExp(val);
		}

		static void EventSetTimer(int secs)
		{
			::EventSetTimer(secs);
		}

		static void EventKillTimer()
		{
			::EventKillTimer();
		}

		static bool MathIsValidNumber(double val)
		{
			return ::MathIsValidNumber(val);
		}

		static int MathCeil(double val)
		{
			return (int)::MathCeil(val);
		}

		static void MathSrand()
		{
			::MathSrand(::GetTickCount());
		}

		static int MathRand()
		{
			return ::MathRand();
		}
		
		static IString DoubleToString(double val)
		{
		    return IString(::DoubleToString(val));
		}
		
		static IString IntegerToString(long val)
		{
		    return IString(::IntegerToString(val));
		}

		static double NormalizeDouble(double price, int digits)
		{
			return ::NormalizeDouble(price, digits);
		}

		static int Digits()
		{
			return ::Digits();
		}
};
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppInteroperability.h"

#endif
#endif
//+------------------------------------------------------------------+
