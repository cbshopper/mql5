/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_VALUES_ANALYZERS
#define FILE_VALUES_ANALYZERS

#include "BoolsArray.h"
#include "ValueAnalyzer.h"
#include "../../Interoperability/GenericObjectArray.h"

//+------------------------------------------------------------------+
class CValuesAnalyzers{
    private:
        CBoolArray m_Bools;
        IGenericObjectArray<CValueAnalyzer> m_Analyzers;
        CPastPoint m_LastFound;
		
    public:
        CValuesAnalyzers()
        {
            m_Analyzers.Resize(CBoolArray::ARRAY_SIZE_GROWTH);
        }
        
        void SearchForProfit(double lastEstablishingMinimumMaximum, double upperLimit, double lowerLimit, bool buy, CPastPoint &point, bool initial = true, bool reverseSymbol = false, bool reverseGlobal = false)
        {
            int nr = m_Bools.ReturnFirstFalseBoolNr();
            
            m_Bools.SetBoolTrue(nr);
            if(nr == m_Analyzers.Size())
            {
                m_Analyzers.Resize(m_Analyzers.Size() + CBoolArray::ARRAY_SIZE_GROWTH);
            }
            (*(m_Analyzers.GetPointerToValue(nr))).SearchForProfit(lastEstablishingMinimumMaximum, upperLimit, lowerLimit, buy, point, initial, reverseSymbol, reverseGlobal);
        }
        


        bool CheckProfit(IString &pair, double val, double &diffrence, bool log)
        {//if many will happen, only one returned
            bool guard = false;
            
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                if(m_Bools.GetBool(i))
                {
                    double diff;
                    
                    if((*(m_Analyzers.GetPointerToValue(i))).CheckProfit(pair, val, diff, log))
                    {
                        m_LastFound = (*(m_Analyzers.GetPointerToValue(i))).ReturnPoint();
                        guard = true;
                        diffrence += diff;
                        m_Bools.SetBoolFalse(i);
                    }
                }
            }
            return guard;
        }
        
        CPastPoint ReturnPoint()
        {
            return m_LastFound;
        }
        
        void Log(IString &symbol)
        {
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                if(m_Bools.GetBool(i))
                {
                    (*(m_Analyzers.GetPointerToValue(i))).Log(symbol);
                }
            }
        }   
        
        double Profit()
        {
            double profit = 0.0;
        
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                profit += (*(m_Analyzers.GetPointerToValue(i))).Profit();
            }
            return profit;
        }
        
        double ProfitMinusSpread(IString &symbol)
        {
            double profit = 0.0;
        
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                profit += (*(m_Analyzers.GetPointerToValue(i))).ProfitMinusSpread(symbol);
            }
            return profit;
        }
        
        double ProfitGains()
        {
            double profit = 0.0;
        
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                profit += (*(m_Analyzers.GetPointerToValue(i))).ProfitGains();
            }
            return profit;
        } 
        
        int GainCount()
        {
            int count = 0;
        
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                count += (*(m_Analyzers.GetPointerToValue(i))).GainCount();
            }
            return count;
        }    
        
        int LossCount()
        {
            int count = 0;
        
            for(int i=0;i<m_Analyzers.Size();i++)
            {
                count += (*(m_Analyzers.GetPointerToValue(i))).LossCount();
            }
            return count;
        }    
};
//+------------------------------------------------------------------+
#endif