/*Copyright 2021 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_NET_NEURON
#define FILE_NET_NEURON

#include "ActivationFunction.h"
#include "../../../Interoperability/Interoperability.h"

//+------------------------------------------------------------------+
class CIntArray{
    public:
        IGenericArray<int> Values;
        
        void Init(int am)
        {
            Values.Resize(am);
        }        
};
//+------------------------------------------------------------------+
class CNetNeuron{
    private:
        CActivationFunction m_afFunction;
        IGenericArray<double> m_dWeights;
        IGenericObjectArray<CIntArray> m_dPredecessors;
        IGenericArray<double> m_dTmpInputs;
        
        void CalculateAFInputs(IGenericArray<double> &dInputs)
        {
            for (int i = 0; i < m_afFunction.Dimension(); i++)
            {
                m_dTmpInputs.SetValue(i, 0.0);
                for(int nr = 0;nr<((*m_dPredecessors.GetPointerToValue(i))).Values.Size();nr++)
                {
                    m_dTmpInputs.SetValue(i, m_dTmpInputs.GetValue(i) + dInputs.GetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr)) * m_dWeights.GetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr)));
                }
            }
        }
        
        void ChoosePredecessors()
        {
			   IGenericArray<int> ret;
			   IGenericArray<int> predecessorsAmounts;
			   
			   ret.Resize(m_dWeights.Size());
			   CMathNet::RandomSet(ret);
			   m_dPredecessors.Resize(m_afFunction.Dimension());
			   predecessorsAmounts.Resize(m_afFunction.Dimension());
			   
            int pos = -1;
            int amInRow = (int)IInteroperability::MathCeil(m_dWeights.Size() / ((double)(m_afFunction.Dimension())));

            for (int i = 0; i < m_dWeights.Size(); i++)
            {
                if (i % amInRow == 0)
                {
                    pos++;
                }
                predecessorsAmounts.SetValue(pos, predecessorsAmounts.GetValue(pos) + 1);
            }
            
            for(int i=0;i<m_dPredecessors.Size();i++)
            {
                (*m_dPredecessors.GetPointerToValue(i)).Init(predecessorsAmounts.GetValue(i));
                predecessorsAmounts.SetValue(i, 0);
            }
            
            pos = -1;
            for (int i = 0; i < m_dWeights.Size(); i++)
            {
                if (i % amInRow == 0)
                {
                    pos++;
                }
                (*m_dPredecessors.GetPointerToValue(pos)).Values.SetValue(predecessorsAmounts.GetValue(pos), ret.GetValue(i));
                predecessorsAmounts.SetValue(pos, predecessorsAmounts.GetValue(pos) + 1);
            }
        }
        
    public:
        void Init(int inputsAm, int activationFunctionDimension)
        {
            if (activationFunctionDimension > inputsAm)
            {
                activationFunctionDimension = inputsAm;
            }

            m_afFunction.Init(activationFunctionDimension);
            m_dWeights.Resize(inputsAm);
            
            for (int i = 0; i < m_dWeights.Size(); i++)
            {
                m_dWeights.SetValue(i, CMathNet::Random(-1.0, 1.0));
            }
            ChoosePredecessors();
            m_dTmpInputs.Resize(m_afFunction.Dimension());
        }
        
        double ExitValue(IGenericArray<double> &dInputs)
        {
            CalculateAFInputs(dInputs);
            return m_afFunction.ExitValue(m_dTmpInputs);
        }
        
        double Lern(IGenericArray<double> &dInputs, double dDesiredOutput, double dLernParam)
        {
            CalculateAFInputs(dInputs);
            double dExit = m_afFunction.ExitValue(m_dTmpInputs);

            AdaptByGradient(dInputs, 2.0 * (dExit - dDesiredOutput), dLernParam);
            return (dExit - dDesiredOutput) * (dExit - dDesiredOutput);
        }

        void AdaptByGradient(IGenericArray<double> &dInputs, double dGradient, double dLernParam)
        {
            CalculateAFInputs(dInputs);
            IGenericArray<double> dAFGradientsOnInputs;
            
            dAFGradientsOnInputs.Resize(m_dTmpInputs.Size());

            m_afFunction.GradientsOnInputs(m_dTmpInputs, dAFGradientsOnInputs, dGradient);
            for (int i = 0; i < m_afFunction.Dimension(); i++)
            {
                for(int nr = 0;nr<(*m_dPredecessors.GetPointerToValue(i)).Values.Size();nr++)
                { 
                    double val = dLernParam * dAFGradientsOnInputs.GetValue(i) * dInputs.GetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr));
                    
                    if(IInteroperability::MathIsValidNumber(val))
                    {
                        m_dWeights.SetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr), m_dWeights.GetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr)) - val);
                    }
                }
            }
            m_afFunction.AdaptByGradient(m_dTmpInputs, dGradient, dLernParam);
        }

        void GradientsOnInputs(IGenericArray<double> &dInputs, IGenericArray<double> &dGradients, double dGradient)
        {
            CalculateAFInputs(dInputs);
            IGenericArray<double> dAFGradientsOnInputs;
            
            dAFGradientsOnInputs.Resize(m_dTmpInputs.Size());

            m_afFunction.GradientsOnInputs(m_dTmpInputs, dAFGradientsOnInputs, dGradient);
            for (int i = 0; i < m_afFunction.Dimension(); i++)
            {
                for(int nr = 0;nr<(*(m_dPredecessors.GetPointerToValue(i))).Values.Size();nr++)
                {                
                    dGradients.SetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr), dAFGradientsOnInputs.GetValue(i) * m_dWeights.GetValue((*m_dPredecessors.GetPointerToValue(i)).Values.GetValue(nr)));
                }
            }
        }
};
//+------------------------------------------------------------------+
#endif